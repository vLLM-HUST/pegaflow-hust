"""Finite FIFO stage scheduling with shared source/destination resources.

An operation acquires all resources together and releases all at completion.
Waiting operations hold no device resource. This is a model of owned work,
not a guarantee about unknown platform contention or native kernel overlap.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
import heapq
import itertools
import math


@dataclass(frozen=True)
class Operation:
    name: str
    seconds: float
    resources: tuple[str, ...]
    first_seconds: float | None = None

    def __post_init__(self):
        if not self.name or not math.isfinite(self.seconds) or self.seconds < 0:
            raise ValueError("Finite nonnegative owned operation required")
        if len(set(self.resources)) != len(self.resources):
            raise ValueError("Duplicate operation resource")
        if self.first_seconds is not None and not 0 <= self.first_seconds <= self.seconds:
            raise ValueError("First token must occur within its full operation")


@dataclass(frozen=True)
class Work:
    key: str
    p: int
    d: int
    order: int
    offered: float
    prefill: tuple[Operation, ...]
    decode: tuple[Operation, ...]
    p_done: float | None = None
    d_enqueued: float | None = None
    p_started: float | None = None
    d_started: float | None = None
    actual_first: float | None = None
    completed_operations: frozenset[str] = frozenset()
    active_operations: tuple[tuple[str, float], ...] = ()

    def __post_init__(self):
        if self.p not in (0, 1) or self.d not in (2, 3) or not self.key:
            raise ValueError("An identified P/D assignment is required")
        names = [o.name for o in (*self.prefill, *self.decode)]
        if len(set(names)) != len(names):
            raise ValueError("Unique per-request operation names required")
        if len(self.active_operations) > 1:
            raise ValueError("The declared request operation chain is sequential")


@dataclass
class _Stage:
    work: Work
    node: int
    operations: deque[Operation]
    ready: float


def schedule(work, now, remaining=None, resource_blocks=None):
    """Forecast from actual progress, preserving FIFO and complete decode use.

    At most one executor stage per device runs. Copies can borrow a different
    device's gate without taking that device's executor slot. Future D FIFO
    order follows simulated P completions; already-enqueued D keeps its order.
    Complexity is O(V log V + V J), space O(V+J), with V operation events and
    J live requests. The ready scan has at most four stage heads.
    """
    if not math.isfinite(now) or now < 0:
        raise ValueError("Finite nonnegative forecast origin required")
    work = tuple(work)
    if len({w.key for w in work}) != len(work):
        raise ValueError("Distinct owned requests required")
    queues = [deque() for _ in range(4)]
    active: dict[int, _Stage] = {}
    held: dict[str, tuple[str, str]] = {}
    events, serial = [], itertools.count()
    first, p_done, full, starts = {}, {}, {}, {}
    trace = []

    def event(at, kind, stage, operation=None):
        heapq.heappush(events, (at, next(serial), kind, stage, operation))

    def chain(w, p):
        operations = w.prefill if p else w.decode
        return deque(o for o in operations if o.name not in w.completed_operations)

    for node in (0, 1):
        for w in sorted((w for w in work if w.p == node and w.p_done is None), key=lambda w: w.order):
            queues[node].append(_Stage(w, node, chain(w, True), now))
    for node in (2, 3):
        ready = sorted((w for w in work if w.d == node and w.p_done is not None),
                       key=lambda w: (w.d_enqueued if w.d_enqueued is not None else w.p_done, w.order))
        for w in ready:
            p_done[w.key] = w.p_done
            queues[node].append(_Stage(w, node, chain(w, False), now))
    for w in work:
        if w.actual_first is not None:
            first[w.key] = w.actual_first

    # An accepted layout commit borrows the union of its device gates. Its
    # generation-checked execution is nonblocking if an owned operation holds
    # any of them; do not model a commit that the executor must defer.
    for resource, until in (resource_blocks or {}).items():
        if not math.isfinite(until) or until < now:
            raise ValueError("Invalid initial commit resource interval")
        if until > now:
            held[resource] = ("__commit__", resource)
            heapq.heappush(events, (until, next(serial), "unblock", None, resource))

    def finish_stage(stage, at):
        del active[stage.node]
        if stage.node < 2:
            p_done[stage.work.key] = at
            queues[stage.work.d].append(_Stage(stage.work, stage.work.d, chain(stage.work, False), at))
        else:
            full[stage.work.key] = at

    # Install real holders before predicting any new acquisition. A started
    # executor waiting for a gate is not falsely installed as a gate holder.
    for node in range(4):
        if not queues[node]:
            continue
        stage = queues[node][0]
        began = stage.work.p_started if node < 2 else stage.work.d_started
        if began is None:
            continue
        active[node] = queues[node].popleft()
        starts[(stage.work.key, node)] = began
        actual = dict(stage.work.active_operations)
        if not actual:
            continue
        if not stage.operations or stage.operations[0].name not in actual:
            raise ValueError("Actual progress does not match the remaining operation chain")
        operation = stage.operations[0]
        elapsed = max(0.0, now - actual[operation.name])
        duration = remaining(stage.work, operation, elapsed) if remaining else max(0, operation.seconds - elapsed)
        if not math.isfinite(duration) or duration < 0:
            raise ValueError("Invalid residual operation estimate")
        identity = stage.work.key, operation.name
        for resource in operation.resources:
            if resource in held:
                raise ValueError("Two actual operations claim the same exclusive resource")
            held[resource] = identity
        if operation.first_seconds is not None and stage.work.key not in first:
            event(now + min(duration, max(0, operation.first_seconds - elapsed)), "first", stage, operation)
        event(now + duration, "finish", stage, operation)

    at = now
    running = {(e[3].work.key, e[4].name) for e in events if e[2] == "finish"}
    while len(full) < len(work):
        changed = True
        while changed:
            changed = False
            for node in range(4):
                if node not in active and queues[node] and queues[node][0].ready <= at:
                    stage = queues[node].popleft()
                    active[node] = stage
                    starts[(stage.work.key, node)] = at
                    changed = True
            for stage in sorted(tuple(active.values()), key=lambda s: (s.ready, s.work.order, s.node)):
                if not stage.operations:
                    finish_stage(stage, at)
                    changed = True
                    continue
                operation = stage.operations[0]
                identity = stage.work.key, operation.name
                if identity in running or any(resource in held for resource in operation.resources):
                    continue
                for resource in operation.resources:
                    held[resource] = identity
                running.add(identity)
                trace.append({"key": stage.work.key, "node": stage.node, "operation": operation.name,
                              "start": at, "end": at + operation.seconds, "resources": operation.resources})
                if operation.first_seconds is not None and stage.work.key not in first:
                    event(at + operation.first_seconds, "first", stage, operation)
                event(at + operation.seconds, "finish", stage, operation)
                changed = True
        if not events:
            if len(full) == len(work):
                break
            raise ValueError("Owned operation graph cannot make progress")
        at, _, kind, stage, operation = heapq.heappop(events)
        if kind == "unblock":
            held.pop(operation)
            continue
        if kind == "first":
            first.setdefault(stage.work.key, at)
            continue
        identity = stage.work.key, operation.name
        running.remove(identity)
        for resource in operation.resources:
            if held.pop(resource) != identity:
                raise ValueError("Resource ownership changed before completion")
        if stage.operations.popleft() is not operation:
            raise ValueError("Operation completion order changed")
        stage.ready = at
    if any(queues) or active or held or len(first) != len(work):
        raise ValueError("Incomplete first-token/full-completion forecast")
    return {"P_end": p_done, "first": first, "full": full,
            "stage_start": starts, "operations": trace}

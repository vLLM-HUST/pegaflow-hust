"""Independent bracket audit on original paths, with both baselines retained."""

from __future__ import annotations

import argparse
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import sys
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent / "code"))
from audit import audit_pair, read, sha
from confirmation_control import ARMS, SERVING_PHASE
from confirmation_state import require_same, state_digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--p", type=Path, required=True)
    parser.add_argument("--d", type=Path, required=True)
    parser.add_argument("--workload", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("Refusing to overwrite a bracket report")
    protocol = read(args.p / "protocol.json")
    contract = read(args.p / "confirmation-contract.json")
    assert protocol["candidate_revision"] == "detached-calendar-live-01"
    assert protocol["objective_metric"] == "ttft_seconds"
    require_same([list(pair) for pair in ARMS], protocol["confirmation_arms"], "arm policy order")
    require_same(contract["arms"], protocol["confirmation_arms"], "contract order")
    assert protocol["confirmation_serving_phase"] == contract["serving_phase"] == SERVING_PHASE
    assert protocol["arrival_condition"]["name"] == "poisson-300"
    assert protocol["arrival_condition"]["rate_rps"] == 0.49032341538142143
    assert protocol["actual_initial_cache_equality_required"] is True
    assert protocol["whole_bracket_same_allocation_required"] is True
    assert contract["no_test_data_used_as_initial_seed"] is True
    assert contract["all_planning_migration_and_final_drain_costs_retained"] is True
    assert contract["frozen_core_sha256"] == protocol["controller_core_sha256"]
    assert sha(args.p / "executed-control/code/run.py") == contract["frozen_core_sha256"]
    seed = read(args.p / "operation-seed-manifest.json")
    identity = read(args.p / "identity-initial.json")
    require_same(identity["D"], read(args.d / "identity-initial.json"), "independent D identity")
    require_same(identity["P"]["sources"], identity["D"]["sources"], "shared P/D code")
    require_same(contract["source_manifest"], identity["P"]["sources"], "source contract")
    for name, expected in contract["source_manifest"].items():
        assert sha(args.p / "executed-control" / name) == expected
    expected_state, expected_warmup = None, None
    for arm, policy in ARMS:
        for suffix in ("before", "after"):
            observed = read(args.p / ("identity-" + arm + "-" + suffix + ".json"))
            require_same(identity, observed, "physical/container/source identity")
            require_same(identity["D"], read(args.d / (arm + "-" + suffix + ".json")), "D identity per arm")
        directory = args.p / arm / SERVING_PHASE
        state_digest(read(directory / "prewarmup-inventory.json"), empty=True)
        actual = state_digest(read(directory / "initial-inventory.json"))
        if expected_state is None:
            expected_state = actual
        require_same(expected_state, actual, "canonical initial state")
        state = read(directory / "initial-state-contract.json")
        assert state["digest"] == state["reference"] == actual
        assert state["empty_before_warmup_passed"] is True
        assert state["policy_phase"] == policy and state["serving_phase"] == SERVING_PHASE
        for name, expected in seed.items():
            assert sha(args.p / arm / "operation-seed" / name) == expected
        warmup = read(directory / "integrated-warmup.json")
        assert len(warmup) == 2
        tokens = []
        for item in warmup:
            assert item["passed"] is True
            assert item["copy"]["status"] == "copied" and item["D"]["num_cached_tokens"] >= 128
            assert len(item["cold"]["output_token_ids"]) == 128
            assert item["cold"]["output_token_ids"] == item["D"]["output_token_ids"]
            assert item["P"]["output_token_ids"][0] == item["D"]["output_token_ids"][0]
            tokens.append(item["D"]["output_token_ids"])
        if expected_warmup is None:
            expected_warmup = tokens
        require_same(expected_warmup, tokens, "warmup exact outputs")
    require_same(identity, read(args.p / "identity-final.json"), "final whole bracket identity")
    require_same(identity["D"], read(args.d / "identity-final.json"), "final D identity")
    assert read(args.d / "node-complete.json")["finished"] == len(ARMS)
    reports = {}
    for treatment in ("T-off", "T-on"):
        for label in ("B-before", "B-after"):
            pair_output = args.output.with_name(args.output.stem + "-" + treatment + "-" + label + ".json")
            paths = {"baseline": (args.p / label, args.d / label, SERVING_PHASE),
                     "treatment": (args.p / treatment, args.d / treatment, SERVING_PHASE)}
            options = SimpleNamespace(p=args.p, d=args.d, workload=args.workload, output=pair_output)
            with redirect_stdout(io.StringIO()):
                reports[treatment + "/" + label] = audit_pair(options, arm_roots=paths)
    report = {"passed": True, "arms": [arm for arm, _ in ARMS], "requests_per_arm": 95,
              "strict_initial_cache_equal": True, "same_allocation_shared_sources_passed": True,
              "independent_full_pair_checks_against_both_baselines": reports,
              "clean_hardware_or_randomized_causal_proof": False,
              "p99_is_single_batch_max": True,
              "evidence_path_mapping": {arm: str(args.p / arm / SERVING_PHASE) for arm, _ in ARMS}}
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: value for key, value in report.items() if key != "independent_full_pair_checks_against_both_baselines"}))


if __name__ == "__main__":
    main()



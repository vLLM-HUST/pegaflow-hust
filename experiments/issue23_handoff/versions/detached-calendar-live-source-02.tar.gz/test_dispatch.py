"""Exercise the new real formal dispatcher, not a new NPU qualification."""

import ast
import contextlib
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, replace
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import threading
import time
from types import SimpleNamespace
import unittest

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
sys.path[:0] = [str(REPO / "python"), str(HERE / "code"), str(HERE.parent)]
import pegaflow
pegaflow.__path__.insert(0, str(HERE / "overlay/pegaflow"))
from arrivals import causal_ready
from pipeline import DevicePipeline
from pegaflow.detached_calendar import DetachedCalendarQueues
from pegaflow.joint_policy import Calendar, Costs, Demand, Layout, best_route, decode_boundary
from pegaflow.joint_queue import QueueLedger
from pegaflow.placement_cost import ObservedLatencyModel
from pegaflow.resource_headroom_profile import HeadroomOperationCosts
from pegaflow.resource_profile import route_order
from pegaflow.pending_planner import OpportunityTrigger, plan_opportunity
from cache_live_bridge import shifted_profile


class DispatcherTests(unittest.TestCase):
    def test_off_and_opportunity_share_dispatch_and_release_contract(self):
        source = ast.parse((HERE / "code/run.py").read_text(encoding="utf-8"))
        nodes = [n for n in source.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))
                 and n.name in ("Policy", "ResourcePolicy", "freeze_completed", "formal")]
        layout = Layout(((),) * 4, (1024,) * 4, (0,) * 4)
        model = ObservedLatencyModel(.001, 0, 0, 3, 0, True)
        costs = Costs((model,) * 4, (.005, .005), 0, 0, 0, 0, 0, 1)
        def generate(node, row, **options):
            time.sleep(.001)
            if options.get("first_observer"):
                options["first_observer"]()
            if node >= 2:
                time.sleep(.005)
            end = .001 if node < 2 else .006
            return {"id": row["id"], "prompt_tokens": 1, "num_cached_tokens": 0,
                    "raw_metrics": dict(queued_ts=0, scheduled_ts=0, first_token_ts=.001, last_token_ts=end),
                    "output_token_ids": [7] * (1 if node < 2 else 128)}, {
                    "first_seconds": .001, "complete_seconds": end}
        def dump(path, value):
            with path.open("x", encoding="utf-8") as stream:
                json.dump(value, stream)
        backend = SimpleNamespace(views=lambda: (), cached_views=lambda: (), close=lambda: None,
            copy_context=lambda *args: contextlib.nullcontext(),
            locked=lambda nodes, **kwargs: contextlib.nullcontext(), events=[])
        namespace = dict(threading=threading, time=time, deque=deque, Calendar=Calendar,
            contextlib=contextlib, ThreadPoolExecutor=ThreadPoolExecutor,
            DevicePipeline=DevicePipeline, QueueLedger=QueueLedger, DetachedQueues=DetachedCalendarQueues,
            seed_operations=lambda *_: HeadroomOperationCosts(costs),
            Layout=SimpleNamespace(current=lambda _: layout),
            demand=lambda row: Demand(row["id"], row["task"], 1, ()),
            replace=replace, best_route=best_route, decode_boundary=decode_boundary, route_order=route_order,
            generate=generate, asdict=asdict, json=json, selected_guard=lambda *args: None,
            handoff=lambda *args: (0, {"status": "resident"}), encode=lambda v: v,
            causal_ready=causal_ready, CommitConflict=RuntimeError, UnstableInventory=RuntimeError,
            OpportunityTrigger=OpportunityTrigger, plan_opportunity=plan_opportunity,
            shifted_profile=shifted_profile, dump=dump)
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "real-detached-formal", "exec"), namespace)
        rows = [{"id": f"{task}:{step}", "task": task, "step_id": step,
                 "reusable_tokens_no_eviction": 0} for step in range(2) for task in ("a", "b")]
        for mode in ("off", "opportunity"):
            with self.subTest(mode=mode), TemporaryDirectory() as temporary:
                output = Path(temporary)
                results = namespace["formal"]("treatment", backend, rows, costs, .001, output,
                    pipeline=True, causal_arrivals=True, event_queue_policy=True, slow_policy=mode)
                ledger = json.loads((output / "event-queue-ledger.json").read_text())
                self.assertEqual(len(results), 4)
                self.assertEqual(ledger["resource_live_requests"], 0)
                self.assertFalse(ledger["expensive_forecast_holds_live_progress_mutex"])
                self.assertEqual(len(ledger["resource_operation_events"]), 16)
                self.assertEqual(len(ledger["detached_decisions"]), 8)
                self.assertTrue(all(r["P_post_model_ledger_seconds"] >= 0 for r in results))
                if mode == "off":
                    self.assertEqual(json.loads((output / "policy.json").read_text()), [])


if __name__ == "__main__":
    unittest.main()

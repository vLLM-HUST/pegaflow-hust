#!/usr/bin/env bash
set -euo pipefail
task_role=${1:?P or D}
case "$task_role" in P|D) ;; *) exit 2 ;; esac
task_root=/root/issue23-event-queue/20261014
task_attempt=${2:?New two-digit attempt number}
case "$task_attempt" in [0-9][0-9]) ;; *) exit 2 ;; esac
task_output="$task_root/$task_role-formal-event-queue-ab-$task_attempt"
test ! -e "$task_output"
test ! -e "$task_output-launcher.log"
export ISSUE23_PIPELINE_REPLAY=1 ISSUE23_JOINT_ROOT="$task_root"
export ISSUE23_JOINT_PYTHON=/root/issue23-tools/pegaflow-joint-pipeline-01/.venv/bin/python
case "$task_role" in
 D) task_script=node.py; task_extra=() ;;
 P) /usr/local/python3.12.13/bin/python3 "$task_root/code/wait_d_ready.py" \
     --url http://10.17.119.71:18390/ --timeout 120 --output "$task_output-prelaunch-D-ready.json"
    task_script=bootstrap_candidate.py
    task_extra=(--pipeline-reference /root/issue23-joint/20261014/P-formal-joint-ab-02 \
                --arrival-manifest "$task_root/arrival-suite-high-03.json" \
                --arrival-condition poisson-150 --event-queue-policy) ;;
esac
setsid /usr/local/python3.12.13/bin/python3 "$task_root/code/supervise.py" \
 --output "$task_output" --timeout 10800 --memory-stop-gib 56 \
 --job-kind exposed_replay_event_queue_full_policy_formal_ab \
 -- bash "$task_root/code/env.sh" "$task_root/code/$task_script" --output "$task_output" "${task_extra[@]}" \
 > "$task_output-launcher.log" 2>&1 < /dev/null &
task_pid=$!
sleep 1
ps -o pid,pgid,sid,args -p "$task_pid"

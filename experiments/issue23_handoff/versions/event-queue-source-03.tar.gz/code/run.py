"""Four-instance full-policy A/B with explicit copies and causal open arrivals."""

from __future__ import annotations

import argparse
import contextlib
import json
import math
import signal
import subprocess
import sys
import threading
import time
import urllib.request
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, is_dataclass, replace

from common import (AGENT_PORT, D_IP, META_GRPC, META_HTTP, MODEL, P_IP, ROOT,
                    assert_port_free, cache_url, dump, file_sha, rpc, stop, wait, worker_url)
from legacy_node import Workers
from pegaflow.joint_policy import Calendar, Costs, Demand, Layout, Remove, best_route, decode_boundary, plan_layout
from pegaflow.joint_queue import QueueLedger
from pegaflow.joint_runtime import Backend, CommitConflict, json_rpc
from pegaflow.placement_cost import ObservedLatencyModel
from pegaflow.placement_executor import UnstableInventory
from pipeline import DevicePipeline
from arrivals import causal_ready, load_condition


def encode(value):
    if is_dataclass(value):
        return encode(asdict(value))
    if isinstance(value, bytes):
        return value.hex()
    if isinstance(value, (set, frozenset, tuple)):
        return [encode(v) for v in value]
    if isinstance(value, list):
        return [encode(v) for v in value]
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    return value


def save_candidate_protocol(output, protocol):
    reference = output / "reference-protocol-before-candidate.json"
    if reference.exists():
        raise ValueError("Candidate protocol was already finalized")
    (output / "protocol.json").rename(reference)
    dump(output / "protocol.json", protocol)


def generate(node, row, *, prefix=0, cold=False, first_observer=None):
    role, slot = ("P", node) if node < 2 else ("D", node - 2)
    payload = json.dumps({"row": row, "cold": cold, "max_prefix_blocks": prefix}).encode()
    request = urllib.request.Request(worker_url(role, slot) + "/generate", data=payload,
                                     headers={"Content-Type": "application/json"})
    started, first, result, token = time.monotonic(), None, None, None
    with urllib.request.urlopen(request, timeout=600) as response:
        for raw in response:
            event = json.loads(raw)
            if event["event"] == "first_token":
                if first is not None:
                    raise ValueError("Duplicate first-token event")
                first, token = time.monotonic() - started, event["token_id"]
                if first_observer is not None:
                    first_observer()
            elif event["event"] == "complete":
                result = event["result"]
            else:
                raise RuntimeError(str(event))
    if result is None or first is None or token != result["output_token_ids"][0] or result["id"] != row["id"]:
        raise ValueError("Streaming/output identity gate failed")
    if result["rdma_bytes"] != 0 and not cold:
        raise ValueError("Worker performed an unpriced implicit remote fetch")
    return result, {"first_seconds": first, "complete_seconds": time.monotonic() - started}


def backend_for(ready):
    return Backend([cache_url("P" if n < 2 else "D", n % 2) for n in range(4)],
                   [f"{P_IP if n < 2 else D_IP}:{50300 + n % 2}" for n in range(4)],
                   [r["instance_id"] for r in ready])


def wait_for_d_after_preload(processes, directory, timeout=3600):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if any(child.poll() is not None for child in processes):
            raise RuntimeError("Preloaded P worker exited while waiting for D")
        try:
            state = rpc(f"http://{D_IP}:{AGENT_PORT}/status", timeout=3)
        except OSError:
            time.sleep(2)
            continue
        if (state.get("ready") is not True or state.get("cursor") != 0
                or state.get("phase") is not None or state.get("children") != []):
            raise ValueError("D controller is not a fresh unused owned phase controller")
        dump(directory / "D-controller-available.json", state)
        return
    raise TimeoutError("D controller unavailable within bounded P preload wait")


def services(phase, output, preload_p=False):
    from pegaflow._bin_utils import binary_env, find_binary

    directory = output / phase
    directory.mkdir(exist_ok=False)
    assert_port_free(P_IP, (META_GRPC, META_HTTP))
    log = (directory / "meta.log").open("x", encoding="utf-8")
    meta = subprocess.Popen([str(find_binary("pegaflow-metaserver-py")), "--addr", f"{P_IP}:{META_GRPC}",
                             "--http-addr", f"{P_IP}:{META_HTTP}"], env=binary_env(), stdout=log, stderr=subprocess.STDOUT)
    workers = Workers("P", P_IP, output / "workers")
    d_start_requested = False
    try:
        wait(f"http://{P_IP}:{META_HTTP}/health", (meta,), timeout=180)
        if preload_p:
            if phase != "calibration":
                raise ValueError("Early P loading is only permitted before calibration")
            workers.start(phase)
            p_ready = [wait(worker_url("P", slot) + "/ready", workers.children, timeout=900)
                       for slot in (0, 1)]
            if any(value.get("phase") != phase or value.get("role") != "P"
                   or value.get("slot") != slot or not value.get("instance_id")
                   for slot, value in enumerate(p_ready)):
                raise ValueError("Preloaded P identity/phase differs")
            dump(directory / "P-preload-ready.json", {"ready": p_ready,
                 "ready_unix": time.time(), "formal_sampling_started": False,
                 "reuse_for_same_calibration_phase": True, "D_wait_timeout_seconds": 3600})
            print(json.dumps({"phase": "P_preloaded_waiting_for_D", "P_instances": 2,
                              "tp": 1, "formal_sampling_started": False}), flush=True)
            wait_for_d_after_preload(workers.children, directory)
        d_start_requested = True
        rpc(f"http://{D_IP}:{AGENT_PORT}/start", {"phase": phase})
        if not preload_p:
            workers.start(phase)
        ready = [wait(worker_url("P" if n < 2 else "D", n % 2) + "/ready", workers.children, timeout=1800) for n in range(4)]
        if any(r.get("phase") != phase or not r.get("instance_id") for r in ready):
            raise ValueError("Actual four-instance readiness failed")
        dump(directory / "readiness.json", ready)
        return directory, backend_for(ready), workers, meta, log
    except BaseException:
        workers.close()
        if d_start_requested:
            with contextlib.suppress(OSError):
                rpc(f"http://{D_IP}:{AGENT_PORT}/abort", {}, timeout=90)
        stop([meta])
        log.close()
        raise


def close_services(phase, workers, meta, log):
    workers.close()
    rpc(f"http://{D_IP}:{AGENT_PORT}/stop", {"phase": phase}, timeout=120)
    stop([meta])
    log.close()


def demand(row):
    preview = json_rpc(worker_url("P", 0) + "/preview", {"row": row})
    return Demand(row["id"], row["task"], row["prompt_tokens"], tuple(bytes.fromhex(v) for v in preview["hashes"]))


def handoff(backend, source, destination, hashes, limit):
    try:
        event = backend.fetch_prefix(source, destination, hashes[:limit])
        return limit, event
    except (CommitConflict, UnstableInventory) as error:
        # No free capacity is a legal recompute fallback, not a correctness
        # bypass. Unknown HTTP outcomes/timeouts propagate and stop this arm.
        view = backend.views()
        local = Layout.current(view).prefix(destination, hashes)
        return min(local, limit), {"status": "capacity_or_snapshot_fallback", "reason": str(error)}


def warmups(backend, rows, directory):
    results = []
    for lane, row in enumerate(rows):
        item = demand(row)
        cold, cold_wire = generate(lane + 2, row, cold=True)
        p, _ = generate(lane, row, prefix=0)
        limit, copy = handoff(backend, lane, lane + 2, item.hashes, len(item.hashes))
        d, _ = generate(lane + 2, row, prefix=limit)
        if d["output_token_ids"] != cold["output_token_ids"] or p["output_token_ids"][0] != d["output_token_ids"][0]:
            raise ValueError("Integrated actual-copy warmup output gate failed")
        if copy.get("status") != "copied" or d["num_cached_tokens"] < 128:
            raise ValueError("Warmup did not exercise explicit complete-prefix RDMA restore")
        results.append({"lane": lane, "cold": cold, "cold_wire": cold_wire, "P": p, "D": d, "copy": copy, "passed": True})
    dump(directory / "integrated-warmup.json", encode(results))
    return results


def causal_order(rows, tasks):
    grouped = {task: deque(r for r in rows if r["task"] == task) for task in sorted(tasks)}
    for values in grouped.values():
        steps = [r["step_id"] for r in values]
        if not steps or steps != sorted(set(steps)):
            raise ValueError("Whole-session causal ledger failed")
    ordered = []
    while any(grouped.values()):
        for values in grouped.values():
            if values:
                ordered.append(values.popleft())
    return ordered


def calibrate(backend, rows, directory):
    records = []
    # Isolated calibration tasks only; process each original input once.
    for index, row in enumerate(rows):
        lane = index % 2
        item = demand(row)
        p, pw = generate(lane, row, prefix=len(item.hashes))
        boundary, copied = handoff(backend, lane, lane + 2, item.hashes, len(item.hashes))
        d, dw = generate(lane + 2, row, prefix=boundary)
        if p["output_token_ids"][0] != d["output_token_ids"][0]:
            raise ValueError("Calibration P/D first-token gate failed")
        records.append({"row_id": row["id"], "lane": lane, "P": p, "D": d, "P_wire": pw, "D_wire": dw, "handoff": copied})
        dump(directory / f"calibration-{index:03d}.json", encode(records[-1]))
    # Real reverse and same-host copies qualify the paths used by planning.
    transfer_events = []
    past = [demand(row) for row in rows]
    for source, destination in ((2, 1), (1, 3), (0, 1), (2, 3)):
        views = backend.views()
        state = Layout.current(views)
        candidates = [(state.prefix(source, item.hashes), item) for item in past]
        length, item = max(candidates, key=lambda value: value[0])
        if not length:
            raise ValueError("Calibration copy source unavailable")
        length = max(1, min(length, state.prefix(destination, item.hashes) + 1))
        chain = item.hashes[:length]
        # Select one closed optional allocation, not cleanup-all. This prices a
        # real eviction RPC and makes room for a small qualified copy direction.
        duplicate = state.prefix(destination, chain) == length
        victim = next((unit for unit in views[destination].units if not unit.protected
                       and ((chain[-1] in unit.keys) if duplicate else not (unit.keys & set(chain)))), None)
        if victim is None:
            raise ValueError("Cannot qualify a copy while calibration allocations are leased")
        backend.remove(Remove(destination, (victim.identity,)), backend.inventory(destination), None)
        dump(directory / f"copy-direction-{source}-{destination}-intent.json", encode({
            "source": source, "destination": destination, "prefix_blocks": length,
            "removed": backend.events[-1], "source_inventory": backend.inventory(source),
            "destination_inventory_after_removal": backend.inventory(destination)}))
        event = backend.fetch_prefix(source, destination, chain)
        if event["status"] != "copied":
            raise ValueError("Declared copy direction was not actually exercised")
        original = next(record for record in records if record["row_id"] == item.key)
        row = next(row for row in rows if row["id"] == item.key)
        restored, wire = generate(destination, row, prefix=length)
        expected = original["D"]["output_token_ids"] if destination >= 2 else original["D"]["output_token_ids"][:1]
        if restored["output_token_ids"] != expected:
            raise ValueError("Explicit reverse/same-host copy did not preserve the consumer output")
        transfer_events.append({"source": source, "destination": destination, "event": event,
                                "restored": restored, "wire": wire, "output_equal": True})
    return records, transfer_events


def fit(records, events, bytes_per_token, warmup_records):
    models, samples, decodes = [], {}, []
    for node in range(4):
        role, lane = ("P", node) if node < 2 else ("D", node - 2)
        samples[str(node)] = [(r[role]["uncached_prompt_tokens"],
                              r[role]["num_cached_tokens"] * bytes_per_token,
                              r["P_wire"]["complete_seconds"] if role == "P" else r["D_wire"]["first_seconds"])
                             for r in records if r["lane"] == lane]
        if role == "D":
            cold = warmup_records[lane]
            samples[str(node)].append((cold["cold"]["prompt_tokens"], 0, cold["cold_wire"]["first_seconds"]))
        model = ObservedLatencyModel.fit(tuple(samples[str(node)]))
        if not model.rdma_observed:
            raise ValueError("Resident restore cost is unobserved; cannot price a free cache path")
        models.append(model)
        if role == "D":
            values = [r["D_wire"]["complete_seconds"] - r["D_wire"]["first_seconds"] for r in records if r["lane"] == lane]
            decodes.append(sum(values) / len(values))
    direction = {name: [] for name in ("pd", "dp", "same")}
    for event in events:
        if event.get("kind") == "copy":
            name = event["direction"] if event["direction"] in ("pd", "dp") else "same"
            direction[name].append((event["receipt"]["payload_bytes"], event["rpc_seconds"]))
    if not all(direction.values()):
        raise ValueError("Every enabled copy direction requires a real completed measurement")
    # A zero intercept through-origin slope is identifiable from one copy;
    # it is a measured surrogate, not independent wire/host stage estimates.
    slopes = {k: sum(b * s for b, s in v) / sum(b * b for b, _ in v) for k, v in direction.items()}
    removals = [event["rpc_seconds"] for event in events if event.get("kind") == "remove"]
    if not removals:
        raise ValueError("Selected-removal control cost has not been measured")
    costs = Costs(tuple(models), tuple(decodes), 0, slopes["same"], slopes["pd"], slopes["dp"],
                  sum(removals) / len(removals), bytes_per_token)
    return costs, {"costs": asdict(costs), "samples": samples, "transfer_samples": direction,
                   "resident_feature_is_not_wire_bytes": True, "heldout_data_used": False,
                   "eviction_rpc_cost_unmeasured": False, "eviction_samples": removals}


class Policy:
    def __init__(self, backend, costs, event_queue_policy=False):
        self.backend, self.costs = backend, costs
        self.event_queue_policy = event_queue_policy
        self.history, self.records, self.pending, self.guard = [], [], None, threading.Lock()
        self.pool = ThreadPoolExecutor(max_workers=1)

    def completed(self, item, calendar):
        with self.guard:
            self.history.append(item)
            if self.pending is not None and not self.pending.done():
                return
            if self.pending is not None:
                self.pending.result()
            history = tuple(self.history)
            self.pending = self.pool.submit(self.optimize, history, calendar)

    def optimize(self, history, calendar):
        started = time.monotonic()
        cpu_started = time.thread_time()
        record = {"completed_ids": [d.key for d in history], "action_count": 0}
        record["completed_arrivals_seconds"] = {d.key: d.arrival for d in history}
        record["started_seconds"] = started - self.started
        try:
            views = self.backend.views()
            history_for_objective = history
            if self.event_queue_policy:
                origin = min(item.arrival for item in history)
                history_for_objective = tuple(replace(item, arrival=item.arrival - origin) for item in history)
                calendar = None
                record["objective_scope"] = "past-demand working-set replay; not predicted future arrivals"
            remaining = 0.1 - (time.monotonic() - started)
            if remaining <= 0:
                record.update(status="no_action", reason="planning_budget_spent_before_objective")
                return
            plan = plan_layout(Layout.current(views), history_for_objective, self.costs, max_trials=256,
                               deadline_seconds=remaining, calendar=calendar,
                               event_queues=self.event_queue_policy)
            result = self.backend.apply(plan, views, history)
            record.update(plan=asdict(plan), execution=result,
                          action_count=len(result.get("receipts", [])))
        except (CommitConflict, UnstableInventory) as error:
            record.update(status="normal_defer", reason=str(error))
        finally:
            record["total_seconds"] = time.monotonic() - started
            record["cpu_seconds"] = time.thread_time() - cpu_started
            self.records.append(record)

    def close(self):
        self.pool.shutdown(wait=True)
        if self.pending is not None:
            self.pending.result()


def formal(phase, backend, rows, costs, interval, directory, baseline=None, pipeline=False,
           arrival_offsets=None, causal_arrivals=False, event_queue_policy=False):
    ready_rows = [(row, None) for row in rows]
    policy = Policy(backend, costs, event_queue_policy=event_queue_policy) if phase == "treatment" else None
    if policy:
        policy.interval = interval
    started, pending, active_tasks = time.monotonic(), deque(), set()
    if policy:
        policy.started = started
    results, index, lock = [], 0, threading.Lock()
    schedule = tuple(arrival_offsets) if arrival_offsets is not None else tuple(i * interval for i in range(len(rows)))
    if len(schedule) != len(rows) or (causal_arrivals and not pipeline):
        raise ValueError("A matching arrival ledger and independent pipeline are required")
    session_completed = {}
    # The legacy two-slot arm remains available only for archived comparison.
    # Pipeline mode admits every causally eligible arrived session head.
    calendar = Calendar()
    if event_queue_policy and not pipeline:
        raise ValueError("Event-anchored routing requires the independent device pipeline")
    queues = QueueLedger() if event_queue_policy else None

    def route_request(row):
        decision_started = time.monotonic()
        decision_cpu = time.thread_time()
        item = demand(row)
        views = backend.views()
        layout = Layout.current(views)
        with lock:
            now = time.monotonic() - started
            request = replace(item, arrival=now)
            fixed = (sorted({r["task"] for r in rows}).index(row["task"]) % 2,
                     2 + sorted({r["task"] for r in rows}).index(row["task"]) % 2)
            options = {"max_candidates": 64, "fixed_pair": fixed if phase == "baseline" else None}
            if queues is not None:
                options["queues"] = queues
            route, tried, exhaustive = best_route(request, layout, costs, calendar, **options)
            if queues is not None:
                queues.reserve(item.key, route, now)
            else:
                calendar.available = dict(route.calendar.available)
        route_seconds = time.monotonic() - decision_started
        route_cpu_seconds = time.thread_time() - decision_cpu
        return item, route, tried, exhaustive, decision_started, route_seconds, route_cpu_seconds

    def prefill(row, decision):
        item, route = decision[:2]
        before_restore = time.monotonic()
        restore, copied = handoff(backend, route.source, route.p, item.hashes, route.p_blocks)
        before_p = time.monotonic()
        with backend.locked((route.p,)):
            p_submitted = time.monotonic()
            p, p_wire = generate(route.p, row, prefix=restore)
        after_p = time.monotonic()
        return {"P": p, "P_wire": p_wire, "history_fetch": copied,
                "pre_P_wait_and_copy_seconds": before_p - before_restore,
                "P_gate_wait_seconds": p_submitted - before_p,
                "P_submission_seconds": p_submitted - started,
                "P_complete_seconds": after_p - started}

    def decode(row, decision, arrival, p_result, offered=None):
        item, route, tried, exhaustive, decision_started, route_seconds, route_cpu_seconds = decision
        initial_boundary = route.d_blocks
        revalidation_reason = "published_inventory"
        if queues is not None:
            # P has completed, but native admission may reject or evict blocks.
            # Do not assume the P-produced prefix is still fully published.
            try:
                current = Layout.current(backend.views())
                length, seconds = decode_boundary(item, current, costs, route.p, route.d)
            except (CommitConflict, UnstableInventory):
                length, seconds = 0, costs.compute(route.d, item.tokens, 0)
                revalidation_reason = "unstable_inventory_safe_recompute"
            route = replace(route, d_blocks=length)
            queues.revise_decode(item.key, seconds, seconds + costs.decode_seconds[route.d - 2])
        before_handoff = time.monotonic()
        boundary, handed = handoff(backend, route.p, route.d, item.hashes, route.d_blocks)
        before_d = time.monotonic()
        with backend.locked((route.d,)):
            d_submitted = time.monotonic()
            options = {"prefix": boundary}
            if queues is not None:
                options["first_observer"] = lambda: queues.observe(item.key, route.d, "first", time.monotonic() - started)
            d, d_wire = generate(route.d, row, **options)
        end = time.monotonic()
        if p_result["P"]["output_token_ids"][0] != d["output_token_ids"][0]:
            raise ValueError("Formal P/D first-token gate failed")
        if baseline is not None and baseline[row["id"]]["D"]["output_token_ids"] != d["output_token_ids"]:
            raise ValueError("Treatment full output differs from same-input baseline")
        result = {"id": row["id"], "task": row["task"], "step_id": row["step_id"],
                  "arrival_seconds": arrival, "dispatch_seconds": decision_started - started,
                  "route": asdict(route), "route_trials": tried, "route_exhaustive": exhaustive,
                  "route_seconds": route_seconds, "handoff": handed,
                  "route_cpu_seconds": route_cpu_seconds,
                  **p_result, "D": d, "D_wire": d_wire,
                  "handoff_and_wait_seconds": before_d - before_handoff,
                  "D_gate_wait_seconds": d_submitted - before_d,
                  "D_submission_seconds": d_submitted - started,
                  "ttft_seconds": d_submitted - started - arrival + d_wire["first_seconds"],
                  "completion_seconds": end - started - arrival,
                  "offered_arrival_seconds": arrival if offered is None else offered,
                  "causality_wait_seconds": 0 if offered is None else arrival - offered,
                  "offered_to_first_seconds": d_submitted - started - (arrival if offered is None else offered) + d_wire["first_seconds"],
                  "_completed_demand": item,
                  "reusable_tokens_no_eviction": row["reusable_tokens_no_eviction"]}
        if queues is not None:
            result["boundary_revalidation"] = {"before_P": initial_boundary,
                                                "after_actual_P": route.d_blocks,
                                                "future_admission_assumed": False,
                                                "reason": revalidation_reason}
        return result

    def one(row, item, arrival):
        decision = route_request(row)
        return decode(row, decision, arrival, prefill(row, decision))

    futures = {}
    devices = (DevicePipeline(started, observer=queues.observe) if queues is not None
               else DevicePipeline(started)) if pipeline else None
    try:
        context = contextlib.nullcontext(None) if devices else ThreadPoolExecutor(max_workers=2)
        with context as pool, (directory / "requests.jsonl").open("x", encoding="utf-8") as stream:
            while index < len(ready_rows) or pending or futures:
                elapsed = time.monotonic() - started
                while index < len(ready_rows) and schedule[index] <= elapsed:
                    pending.append((*ready_rows[index], schedule[index]))
                    index += 1
                for future in list(futures):
                    if future.done():
                        task = futures.pop(future)
                        active_tasks.remove(task)
                        if devices:
                            result, timing = future.result()
                            result["pipeline_timing"] = timing
                        else:
                            result = future.result()
                        item = result.pop("_completed_demand")
                        session_completed[result["task"]] = result["arrival_seconds"] + result["completion_seconds"]
                        if policy:
                            elapsed_now = time.monotonic() - started
                            with lock:
                                historical_arrival = result["offered_arrival_seconds"] if causal_arrivals else result["arrival_seconds"]
                                policy.completed(replace(item, arrival=historical_arrival),
                                    Calendar({k: max(0, v - elapsed_now) for k, v in calendar.available.items()}))
                        results.append(result)
                        stream.write(json.dumps(encode(result)) + "\n")
                        stream.flush()
                        print(json.dumps({"phase": phase, "finished": len(results), "id": result["id"],
                              "P": result["route"]["p"], "D": result["route"]["d"], "ttft": result["ttft_seconds"]}), flush=True)
                while devices is not None or len(futures) < 2:
                    eligible = next((entry for entry in pending if entry[0]["task"] not in active_tasks), None)
                    if eligible is None:
                        break
                    pending.remove(eligible)
                    active_tasks.add(eligible[0]["task"])
                    if devices:
                        row, _, arrival = eligible
                        offered = arrival
                        if causal_arrivals:
                            arrival = causal_ready(offered, session_completed.get(row["task"], 0))
                        decision = route_request(row)
                        route = decision[1]
                        future = devices.submit(route.p, route.d,
                            lambda row=row, decision=decision: prefill(row, decision),
                            lambda value, row=row, decision=decision, arrival=arrival, offered=offered:
                                decode(row, decision, arrival, value, offered),
                            key=decision[0].key)
                    else:
                        future = pool.submit(one, *eligible)
                    futures[future] = eligible[0]["task"]
                if futures or pending or index < len(ready_rows):
                    time.sleep(0.005)
    finally:
        if devices:
            dump(directory / "pipeline-summary.json", devices.close())
        if queues is not None:
            dump(directory / "event-queue-ledger.json", queues.snapshot())
        if policy:
            policy.close()
            dump(directory / "policy.json", encode(policy.records))
        dump(directory / "cache-actions.json", encode(backend.events))
    dump(directory / "phase-complete.json", {"requests": len(results), "seconds_including_planning_and_final_commit": time.monotonic() - started})
    return results


def load_pipeline_reference(reference, manifest, test, output, arrival_manifest=None, arrival_condition=None):
    protocol = json.loads((reference / "protocol.json").read_text(encoding="utf-8"))
    cost_path = reference / "cost-model.json"
    if (protocol["source_manifest"] != manifest
            or protocol["test_order"] != [row["id"] for row in test]
            or protocol["cost_sha256"] != file_sha(cost_path)
            or protocol["frozen_before_test"] is not True):
        raise ValueError("Pipeline must reuse the exact frozen stream and calibration costs")
    expected = {"tp": 1, "P": 2, "D": 2, "block": 128, "prefill": 128,
                "context": 32768, "dtype": "bfloat16", "P_output": 1, "D_output": 128,
                "pool_bytes_per_instance": 2 * 1024**3, "npu_kv_bytes": 2 * 1024**3,
                "model": str(MODEL)}
    if any(protocol.get(key) != value for key, value in expected.items()):
        raise ValueError("Declared serving configuration or cache budget changed")
    fitted = json.loads(cost_path.read_text(encoding="utf-8"))
    values = dict(fitted["costs"])
    values["service"] = tuple(ObservedLatencyModel(**row) for row in values["service"])
    values["decode_seconds"] = tuple(values["decode_seconds"])
    costs = Costs(**values)
    interval = protocol["arrival_interval_seconds"]
    if isinstance(interval, bool) or not math.isfinite(interval) or interval <= 0:
        raise ValueError("Invalid frozen arrival interval")
    with (output / "cost-model.json").open("xb") as stream:
        stream.write(cost_path.read_bytes())
    protocol.update(execution_mode="independent_P_D_FIFO_queues",
                    global_end_to_end_inflight_limit=None, per_instance_active_limit=1,
                    D_queue_includes_priced_handoff=True,
                    reference_protocol_sha256=file_sha(reference / "protocol.json"),
                    reference_directory=str(reference),
                    reused_test_inputs_are_exposed=True,
                    statistical_scope="paired same-stream pipeline replay; descriptive, not fresh-heldout or stable-p99")
    if arrival_manifest is not None:
        suite, condition = load_condition(arrival_manifest, arrival_condition, protocol)
        with (output / "arrival-manifest.json").open("xb") as stream:
            stream.write(arrival_manifest.read_bytes())
        interval = 1 / condition["rate_rps"]
        protocol.update(arrival_model=condition["distribution"],
                        arrival_condition=condition, arrival_manifest_sha256=file_sha(arrival_manifest),
                        arrival_interval_seconds=interval, TTFT_origin="causal_ready_before_router_queue",
                        nominal_times_identical_actual_times_endogenous=True,
                        objective_metric="offered_to_first_seconds",
                        objective="nearest-rank nominal-offered-to-first-token p99 including upstream causality wait; unique resident bytes tie-break",
                        external_think_time_seconds=0,
                        statistical_scope=suite["sample_scope"])
    dump(output / "protocol.json", protocol)
    dump(output / "pipeline-contract.json", {
        "queues": ["P0", "P1", "D0", "D1"], "global_end_to_end_inflight_limit": None,
        "per_session_causality": True, "reference_protocol_sha256": protocol["reference_protocol_sha256"],
        "recalibration_or_test_based_retuning": False,
        "cost_sha256": protocol["cost_sha256"], "arrival_interval_seconds": interval})
    return costs, interval


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=__import__("pathlib").Path, required=True)
    parser.add_argument("--preload-p-first", action="store_true")
    parser.add_argument("--pipeline-reference", type=__import__("pathlib").Path)
    parser.add_argument("--arrival-manifest", type=__import__("pathlib").Path)
    parser.add_argument("--arrival-condition")
    parser.add_argument("--event-queue-policy", action="store_true")
    args = parser.parse_args()
    if args.event_queue_policy and not args.pipeline_reference:
        raise ValueError("Event queue candidate requires an explicitly frozen pipeline reference")
    if bool(args.arrival_manifest) != bool(args.arrival_condition) or (args.arrival_manifest and not args.pipeline_reference):
        raise ValueError("Arrival replay requires a frozen pipeline reference and an explicit condition")
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))
    manifest = json.loads((ROOT / "workload/manifest.json").read_text(encoding="utf-8"))
    if manifest["requests_sha256"] != file_sha(ROOT / "workload/requests.jsonl"):
        raise ValueError("Frozen workload hash changed")
    rows = [json.loads(line) for line in (ROOT / "workload/requests.jsonl").read_text(encoding="utf-8").splitlines()]
    calibration = causal_order(rows, manifest["calibration_tasks"])
    test = causal_order(rows, manifest["test_tasks"])
    warmup_rows = [next(r for r in calibration if r["task"] == task) for task in manifest["calibration_tasks"]]
    baseline, costs, interval = None, None, None
    if args.pipeline_reference:
        if args.preload_p_first:
            raise ValueError("A frozen pipeline replay cannot enter calibration/preload mode")
        costs, interval = load_pipeline_reference(args.pipeline_reference, manifest, test, args.output,
                                                 args.arrival_manifest, args.arrival_condition)
        protocol = json.loads((args.output / "protocol.json").read_text(encoding="utf-8"))
        if args.event_queue_policy:
            import pegaflow.joint_policy as candidate_policy
            import pegaflow.joint_queue as candidate_queue

            candidate_sources = {}
            for name, module in (("joint_policy", candidate_policy), ("joint_queue", candidate_queue)):
                source_path = __import__("pathlib").Path(module.__file__)
                candidate_sources[name] = {"path": str(source_path), "sha256": file_sha(source_path)}
                snapshot = args.output / (name + "-executed-source.py")
                with snapshot.open("xb") as stream:
                    stream.write(source_path.read_bytes())
            protocol.update(candidate_revision="event-queue-01",
                            policy_source_sha256={name: value["sha256"] for name, value in candidate_sources.items()},
                            queue_forecast="actual FIFO events; future D enqueue follows P completion",
                            D_prefix="revalidated after actual P; no assumed native admission",
                            placement_acceptance="strict predicted latency improvement; no resident-byte reward",
                            cost_adaptation="past-completed full-stage omitted-overhead mean; no fitted switch threshold",
                            objective="nominal-offered-to-first-token p99; memory is a feasibility constraint only",
                            frozen_before_test=False,
                            original_cost_frozen_before_exposed_replay=True,
                            exposed_replay_not_fresh_heldout=True,
                            independent_candidate_audit_required=True)
            save_candidate_protocol(args.output, protocol)
            # Keep the original coefficient hash; declare the post-observation
            # algorithm revision instead of relabelling it preregistered.
            contract_path = args.output / "event-queue-contract.json"
            dump(contract_path, {"candidate_revision": "event-queue-01",
                                 "cost_sha256": protocol["cost_sha256"],
                                 "executed_policy_sources": candidate_sources,
                                 "cost_coefficients_refitted": False,
                                 "algorithm_revised_after_exposed_results": True})
        dump(args.output / "controller-provenance.json", {
            "python": sys.executable, "root": str(ROOT),
            "sources": {name: file_sha(__import__("pathlib").Path(__file__).with_name(name))
                        for name in ("run.py", "pipeline.py", "arrivals.py", "common.py", "worker.py", "legacy_node.py")}})
    d_controller_acquired = False
    try:
        phases = ("baseline", "treatment") if args.pipeline_reference else ("calibration", "baseline", "treatment")
        for phase in phases:
            directory, backend, workers, meta, log = services(
                phase, args.output, preload_p=args.preload_p_first and phase == "calibration")
            d_controller_acquired = True
            try:
                dump(directory / "counters-before.json", [backend.rdma_bytes(n) for n in range(4)])
                warmup_records = warmups(backend, warmup_rows, directory)
                if phase == "calibration":
                    records, paths = calibrate(backend, calibration, directory)
                    sample = next(block for view in backend.views() for block in view.snapshot.blocks.values())
                    bytes_per_token = sample["payload_bytes"] // 128
                    costs, fitted = fit(records, backend.events, bytes_per_token, warmup_records)
                    dump(args.output / "cost-model.json", encode(fitted))
                    # Offered load at measured two-D capacity. This rate uses
                    # calibration only, never held-out service times or reward.
                    interval = sum(r["D_wire"]["complete_seconds"] for r in records) / (2 * len(records))
                    protocol = {"model": str(MODEL), "tp": 1, "P": 2, "D": 2, "block": 128,
                        "prefill": 128, "context": 32768, "dtype": "bfloat16", "P_output": 1, "D_output": 128,
                        "pool_bytes_per_instance": 2 * 1024**3, "npu_kv_bytes": 2 * 1024**3,
                        "arrival_interval_seconds": interval, "open_arrivals_with_per_session_causality": True,
                        "test_order": [r["id"] for r in test], "source_manifest": manifest,
                        "cost_sha256": file_sha(args.output / "cost-model.json"), "slow_candidate_budget": 256,
                        "slow_work_seconds": 0.1, "fast_candidate_budget": 64,
                        "baseline": "fixed task-parity pair; measured fetch/recompute selection; native admission/replacement",
                        "treatment": "four-pair routing + past-only queue-coupled admission/copy/exchange/removal search + native checked real commits",
                        "planning_and_allocation_and_copy_and_wait_included": True,
                        "objective": "nearest-rank arrival-to-first-token p99; unique resident bytes as lexicographic tie-break",
                        "RDMA_byte_scope": "successful application payload; failed partial-wire bytes unavailable, failed RPC wall time included",
                        "host_inventory_authority_GPU_opaque_hits_disabled_in_both_arms": True,
                        "global_optimality_claimed": False, "strict_zero_prefill_claimed": False,
                        "replay_pressure_model": "causal unprotected FIFO approximation, not an exact reconstruction of native TinyLFU admission",
                        "restore_service_feature": "actually accepted resident cache bytes; explicit wire copy priced separately",
                        "frozen_before_test": True, "statistical_scope": "single paired stream; descriptive, not stable-p99 or accuracy"}
                    dump(args.output / "protocol.json", encode(protocol))
                    dump(directory / "copy-paths.json", encode(paths))
                    dump(directory / "cache-actions.json", encode(backend.events))
                else:
                    if args.pipeline_reference:
                        dump(directory / "initial-inventory.json", [backend.inventory(n) for n in range(4)])
                    dump(directory / "formal-arm-started.json", {"phase": phase, "started_unix": time.time(),
                         "protocol_sha256": file_sha(args.output / "protocol.json"), "four_ready": True})
                    result = formal(phase, backend, test, costs, interval, directory, baseline,
                                    pipeline=args.pipeline_reference is not None,
                                    arrival_offsets=None if not args.arrival_manifest else protocol["arrival_condition"]["offered_arrivals_seconds"],
                                    causal_arrivals=args.arrival_manifest is not None,
                                    event_queue_policy=args.event_queue_policy)
                    if phase == "baseline":
                        baseline = {r["id"]: r for r in result}
                dump(directory / "counters-after.json", [backend.rdma_bytes(n) for n in range(4)])
                dump(directory / "final-inventory.json", [backend.inventory(n) for n in range(4)])
            finally:
                if phase == "calibration" and not (directory / "cache-actions.json").exists():
                    dump(directory / "cache-actions.json", encode(backend.events))
                close_services(phase, workers, meta, log)
        dump(args.output / "pair-complete.json", {"completed": True, "independent_audit_pending": True})
        rpc(f"http://{D_IP}:{AGENT_PORT}/finish", {}, timeout=120)
    except BaseException as error:
        dump(args.output / "failure.json", {"type": type(error).__name__, "error": str(error)})
        if d_controller_acquired:
            with contextlib.suppress(OSError):
                rpc(f"http://{D_IP}:{AGENT_PORT}/abort", {}, timeout=120)
        raise


if __name__ == "__main__":
    main()

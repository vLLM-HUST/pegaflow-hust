"""Check captured decode states against an independent float64 delta-rule recurrence."""
import importlib
import json
from pathlib import Path
from types import SimpleNamespace

import torch
import torch_npu  # noqa: F401
from vllm_ascend.utils import enable_custom_op

torch.set_num_threads(4)
enable_custom_op()
torch.npu.set_device(0)
from vllm_ascend.ops.triton.triton_utils import init_device_properties_triton
init_device_properties_triton()
chunk = importlib.import_module('vllm_ascend.ops.triton.fla.chunk')
chunk.get_forward_context = lambda: SimpleNamespace(attn_metadata=None)
chunk.get_pcp_group = lambda: SimpleNamespace(world_size=1)
from vllm_ascend.device.device_op import DeviceOperator
from vllm_ascend.ops.gdn_attn_builder import _build_non_spec_chunked_prefill_metadata
from vllm.model_executor.layers.fla.ops.l2norm import l2norm_fwd

ROOT = Path(__file__).resolve().parent
MODEL_RUN = ROOT / 'probed-decode-closure'
results = {'formula': 'S=exp(g)*S; delta=beta*(v-S@k); S+=delta outer k; o=S@(q/sqrt(K))',
           'state_layout': '[value_head, value_dim, key_dim]', 'ranks': {}, 'restored_states': []}


def stats(a, b):
    a, b = a.detach().cpu(), b.detach().cpu()
    x, y = a.double(), b.double()
    d = x - y
    return {'exact': torch.equal(a, b), 'shape': list(a.shape),
            'max_abs': d.abs().max().item(), 'rms': d.square().mean().sqrt().item(),
            'relative_rms': (d.square().mean() / y.square().mean().clamp_min(1e-30)).sqrt().item(),
            'changed_elements': int((a != b).sum())}


def load(folder, name):
    return torch.load(folder / name, weights_only=True)


def conv(data, x, initial=None, decode=False):
    x = x.npu().contiguous()
    state = torch.zeros((1, 3, x.shape[-1]), dtype=x.dtype, device=x.device) if initial is None else initial.unsqueeze(0).clone().npu()
    out = torch.empty_like(x)
    torch.ops._C_ascend.npu_causal_conv1d_custom(
        out, x, data['conv_weight'].npu().view(x.shape[-1], 4).transpose(0, 1),
        conv_state=state, bias_opt=None,
        query_start_loc_opt=torch.tensor([0, len(x)], dtype=torch.int32, device=x.device),
        cache_indices_opt=torch.tensor([0], dtype=torch.int32, device=x.device),
        initial_state_mode_opt=None if decode else torch.tensor([initial is not None], dtype=torch.bool, device=x.device),
        num_accepted_tokens_opt=None, activation_mode=1, pad_slot_id=-1, run_mode=int(decode))
    return out, state[0]


def operands(data, conv_out):
    q, k, v = [part.reshape(1, len(conv_out), -1, 128).contiguous()
               for part in conv_out.split([1024, 1024, 2048], dim=-1)]
    g, beta = DeviceOperator.fused_gdn_gating(data['A_log'].npu(), data['a'].npu().contiguous(),
                                            data['b'].npu().contiguous(), data['dt_bias'].npu())
    return l2norm_fwd(q)[0], l2norm_fwd(k)[0], v[0], g[0], beta[0]


def prefill(ops, initial=None, capture=None):
    q, k, v, g, beta = ops
    n = len(q)
    state = torch.zeros((1, 16, 128, 128), dtype=torch.float32, device=q.device) if initial is None else initial.unsqueeze(0).transpose(-1, -2).contiguous().npu()
    meta = _build_non_spec_chunked_prefill_metadata(SimpleNamespace(vllm_config=SimpleNamespace(
        model_config=SimpleNamespace(hf_text_config=SimpleNamespace(linear_num_value_heads=32)),
        parallel_config=SimpleNamespace(tensor_parallel_size=2))),
        torch.tensor([0, n], dtype=torch.int32), q.device)
    original_wy = chunk.recompute_w_u_fwd
    if capture is not None:
        def capture_wy(*args, **kwargs):
            w, u = original_wy(*args, **kwargs)
            capture.update(w=w[0].cpu(), u=u[0].cpu(), gcumsum=kwargs['g_cumsum'][0].cpu(),
                           A=kwargs['A'][0].cpu())
            return w, u
        chunk.recompute_w_u_fwd = capture_wy
    try:
        out, final = chunk.chunk_gated_delta_rule(*(x.unsqueeze(0) for x in ops),
            initial_state=state, output_final_state=True,
            cu_seqlens=torch.tensor([0, n], dtype=torch.int32, device=q.device),
            prebuilt_meta=meta, use_qk_l2norm_in_kernel=False)
    finally:
        chunk.recompute_w_u_fwd = original_wy
    return out[0], final[0].transpose(-1, -2).contiguous()


def recurrent(ops, initial):
    q, k, v, g, beta = ops
    state = initial.unsqueeze(0).clone().npu()
    out = torch.ops._C_ascend.npu_recurrent_gated_delta_rule(
        query=q, key=k, value=v, g=g, beta=beta, state=state, scale=128 ** -0.5,
        actual_seq_lengths=torch.tensor([0, len(q)], dtype=torch.int32, device=q.device),
        ssm_state_indices=torch.zeros(len(q), dtype=torch.int32, device=q.device))
    return out, state[0]


def reference(ops, initial=None, checkpoints=()):
    q, k, v, g, beta = [x.detach().cpu().double() for x in ops]
    q, k = q.repeat_interleave(2, dim=1) * (128 ** -0.5), k.repeat_interleave(2, dim=1)
    state = torch.zeros((16, 128, 128), dtype=torch.float64) if initial is None else initial.detach().cpu().double().clone()
    outputs, saved = [], {}
    decay = g.exp()
    for i in range(len(q)):
        state = state * decay[i, :, None, None]
        predicted = (state * k[i, :, None, :]).sum(-1)
        delta = (v[i] - predicted) * beta[i, :, None]
        state = state + delta[:, :, None] * k[i, :, None, :]
        outputs.append((state * q[i, :, None, :]).sum(-1))
        if i + 1 in checkpoints:
            saved[i + 1] = state.clone()
    return torch.stack(outputs), state, saved


def wy_reference(ops, captured=None):
    q, k, v, g, beta = [x.detach().cpu().double() for x in ops]
    k = k.repeat_interleave(2, dim=1)
    q = q.repeat_interleave(2, dim=1) * (128 ** -0.5)
    state = torch.zeros((16, 128, 128), dtype=torch.float64)
    outputs = []
    for start in range(0, len(q), 64):
        stop = min(start + 64, len(q))
        K, V, Q = [x[start:stop].transpose(0, 1) for x in (k, v, q)]
        B = beta[start:stop].transpose(0, 1)
        G = g[start:stop].transpose(0, 1).cumsum(-1)
        if captured is None:
            L = torch.tril((K @ K.transpose(-1, -2)) * (G[:, :, None] - G[:, None, :]).exp() * B[:, :, None], diagonal=-1)
            eye = torch.eye(stop - start, dtype=torch.float64).expand(16, -1, -1)
            A = torch.linalg.solve_triangular(eye + L, eye, upper=False)
            W = A @ (K * (B * G.exp())[:, :, None])
            U = A @ (V * B[:, :, None])
            delta = U - W @ state
            O = (Q @ state) * G.exp()[:, :, None]
            O += torch.tril((Q @ K.transpose(-1, -2)) * (G[:, :, None] - G[:, None, :]).exp()) @ delta
            state = G[:, -1, None, None].exp() * state + K.transpose(-1, -2) @ (delta * (G[:, -1, None] - G).exp()[:, :, None])
            outputs.append(O.transpose(0, 1))
        else:
            # Match the pinned AscendC state kernel: BF16 H/W/U, FP32 matmul accumulation,
            # BF16 decayed deltas and BF16 intermediate chunk states; final state is FP32.
            S = state.to(torch.bfloat16).float()
            W, U = [captured[x][start:stop].transpose(0, 1).float() for x in ('w', 'u')]
            G32 = captured['gcumsum'][start:stop].transpose(0, 1).float()
            delta = U - W @ S
            decay_delta = (delta * (G32[:, -1, None] - G32).exp()[:, :, None]).to(torch.bfloat16).float()
            state = (G32[:, -1, None, None].exp() * S + K.float().transpose(-1, -2) @ decay_delta).double()
    return (torch.cat(outputs) if outputs else None), state.transpose(-1, -2).contiguous()


for rank in (0, 1):
    base = MODEL_RUN / f'rank{rank}'
    dirs = {p: next(base.glob(f'*decode2k-{p}-*')) for p in ('cold1', 'cold2', 'producer', 'reuse')}
    layer = 'language_model.model.layers.0.linear_attn'
    cold = load(dirs['cold1'], f'01-{layer}-inputs.pt')
    producer = load(dirs['producer'], f'01-{layer}-inputs.pt')
    single = load(dirs['producer'], f'02-{layer}-inputs.pt')
    assert len(cold['qkv']) == 2048 and len(producer['qkv']) == 2047 and len(single['qkv']) == 1
    row = {'cold_first_forward_tokens': len(cold['qkv']),
           'producer_first_forward_tokens': len(producer['qkv'])}
    for key in ('qkv', 'a', 'b'):
        row['input-prefix-' + key] = stats(cold[key][:2047], producer[key])
        row['input-token2048-' + key] = stats(cold[key][2047:2048], single[key])
    cold_conv, cold_cs = conv(cold, cold['qkv'])
    producer_conv, producer_cs = conv(producer, producer['qkv'])
    single_conv, single_cs = conv(single, single['qkv'], producer_cs, decode=True)
    cold_ops, producer_ops, single_ops = operands(cold, cold_conv), operands(producer, producer_conv), operands(single, single_conv)
    row['conv-token2048'] = stats(cold_conv[2047:2048], single_conv)
    for name, a, b in zip(('q', 'k', 'v', 'g', 'beta'), cold_ops, single_ops):
        row['operand-token2048-' + name] = stats(a[2047:2048], b)
    prod_out, prod_state = prefill(producer_ops)
    dec_out, dec_state = recurrent(single_ops, prod_state)
    captured_prod = load(dirs['producer'], f'01-{layer}-after.pt')
    captured_dec = load(dirs['producer'], f'02-{layer}-after.pt')
    row['replayed-producer-ssm'] = stats(prod_state, captured_prod['ssm'])
    row['replayed-decode-ssm'] = stats(dec_state, captured_dec['ssm'])
    row['replayed-decode-output'] = stats(dec_out.reshape_as(captured_dec['output_tail']), captured_dec['output_tail'])
    # The single-token kernel gets exactly the same initial state and operands as this reference.
    ref_one_out, ref_one_state, _ = reference(single_ops, prod_state)
    row['decode-vs-float64-same-initial-state'] = stats(dec_state, ref_one_state)
    row['decode-output-vs-float64-rounded-bf16'] = stats(dec_out, ref_one_out.to(torch.bfloat16))
    # Full recurrence provides an independent same-token semantic reference for both execution paths.
    ref_out, ref_state, checkpoints = reference(cold_ops, checkpoints=(2047, 2048))
    captured_wy = {}
    full_out, full_state = prefill(cold_ops, capture=captured_wy)
    row['prefill2048-vs-float64'] = stats(full_state, ref_state)
    row['prefill2047-vs-float64'] = stats(prod_state, checkpoints[2047])
    row['prefill2047-decode1-vs-float64'] = stats(dec_state, checkpoints[2048])
    row['prefill2048-output-vs-float64-rounded-bf16'] = stats(full_out[-4:], ref_out[-4:].to(torch.bfloat16))
    row['cold-repeat-ssm'] = stats(load(dirs['cold1'], f'01-{layer}-after.pt')['ssm'], load(dirs['cold2'], f'01-{layer}-after.pt')['ssm'])
    row['prefill2048-replayed-vs-captured'] = stats(full_state, load(dirs['cold1'], f'01-{layer}-after.pt')['ssm'])
    wy_out, wy_state = wy_reference(cold_ops)
    row['float64-chunk-vs-float64-recurrence-state'] = stats(wy_state, ref_state)
    row['float64-chunk-vs-float64-recurrence-output'] = stats(wy_out, ref_out)
    _, emulated_state = wy_reference(cold_ops, captured_wy)
    row['native-prefill-vs-cpu-bf16-state-emulation'] = stats(full_state, emulated_state)
    torch.save(captured_wy, ROOT / f'rank{rank}-wy-intermediates.pt')
    for path in sorted(dirs['producer'].glob('02-*-after.pt')):
        before_path = dirs['reuse'] / path.name.replace('02-', '01-', 1).replace('-after.pt', '-before.pt')
        source, restored = load(dirs['producer'], path.name), load(dirs['reuse'], before_path.name)
        for kind in ('conv', 'ssm'):
            results['restored_states'].append({'rank': rank, 'layer': path.name[3:-9], 'kind': kind,
                **stats(source[kind], restored[kind + '_before'])})
    results['ranks'][str(rank)] = row
    (ROOT / 'decode-semantic-replay.json').write_text(json.dumps(results, indent=2))
    print(json.dumps({'rank': rank, 'metrics': row}), flush=True)

results['restoration_summary'] = {'count': len(results['restored_states']),
    'all_exact': all(x['exact'] for x in results['restored_states'])}
(ROOT / 'decode-semantic-replay.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results['restoration_summary']), flush=True)

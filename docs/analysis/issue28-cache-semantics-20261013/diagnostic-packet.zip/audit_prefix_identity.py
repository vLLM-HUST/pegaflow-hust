"""Validate every archived loaded plane against publisher and consumer prefix tokens."""
import ast
import collections
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent / 'pegaflow-hust'
PUBLIC = REPO / 'docs/analysis/issue28-qwen35-hybrid-cache-evidence-20261013'
ARCHIVE = ROOT.parent / 'hybrid-cache-acceptance-20261013/final-stage5/evidence'
cases = {x['id']: x['prompt_token_ids'] for x in json.loads((PUBLIC / 'cases.json').read_text())}
out = json.loads((PUBLIC / 'outputs.json').read_text())['records']
packet = json.loads((PUBLIC / 'publications.json').read_text())
tables = packet['index_tables']
intent = re.compile(r'HMA checkpoint save: req=(\S+) ticket=\d+ boundary_tokens=(\[.*?\]) block_ids_by_group=(\[.*?\]) hashes=(\[.*?\])$')
intents = collections.defaultdict(dict)
for log in sorted(ARCHIVE.glob('**/model-*.log')):
    for line in log.read_text(encoding='utf-8').splitlines():
        if m := intent.search(line):
            req, boundaries, slots, hashes = m.groups()
            for boundary, h in zip(ast.literal_eval(boundaries), ast.literal_eval(hashes), strict=True):
                previous = intents[req].get(h)
                assert previous is None or previous == boundary
                intents[req][h] = boundary


def request_tokens(req):
    records = [r for r in out if req.startswith(r['request_id'] + '-') or req == r['request_id']]
    if records:
        identities = {(r['case_id'], tuple(r['token_ids'])) for r in records}
        assert len(identities) == 1, (req, 'ambiguous request identity')
        case, generated = next(iter(identities))
        return cases[case], list(generated), case
    matching = [case for case in cases if '-' + case + '-' in req]
    assert len(matching) == 1, (req, matching)
    case = matching[0]
    return cases[case], [], case


rows, violations = [], []
for item in packet['records']:
    req_idx, rank, layer_idx, slot, digest_idx, hash_indices, sources, locals_ = item
    req, layer = tables['requests'][req_idx], tables['layers'][layer_idx]
    prompt, generated, case = request_tokens(req)
    candidates = sorted(set(sources + locals_))
    assert candidates, 'Missing saved-byte source'
    matches = []
    for hash_idx in hash_indices:
        h = tables['boundary_hashes'][hash_idx]
        consumer_boundary = intents[req][h]
        for publisher_idx in candidates:
            publisher = tables['requests'][publisher_idx]
            if h not in intents[publisher]:
                continue
            boundary = intents[publisher][h]
            source_prompt, source_generated, producer_case = request_tokens(publisher)
            source_all = source_prompt + source_generated
            same = boundary == consumer_boundary and boundary <= len(prompt) and source_all[:boundary] == prompt[:boundary] and len(source_all) >= boundary
            in_prompt = boundary <= len(source_prompt)
            matches.append({'publisher': publisher, 'boundary': boundary,
                            'producer_case': producer_case, 'same_prefix': same,
                            'publisher_boundary_within_prompt': in_prompt,
                            'prefix_token_sha256': hashlib.sha256(json.dumps(source_all[:boundary], separators=(',', ':')).encode()).hexdigest()})
    row = {'consumer': req, 'case': case, 'rank': rank, 'layer': layer, 'slot': slot,
           'byte_sha256': tables['sha256'][digest_idx], 'matches': matches}
    if not matches or not all(x['same_prefix'] and x['publisher_boundary_within_prompt'] for x in matches):
        violations.append(row)
    rows.append(row)

summary = {'loaded_plane_records': len(rows), 'all_prefix_identities_valid': not violations,
    'violations': len(violations), 'consumer_requests': len({r['consumer'] for r in rows}),
    'publisher_boundary_matches': sum(len(r['matches']) for r in rows),
    'boundaries': sorted({x['boundary'] for r in rows for x in r['matches']}),
    'scope': 'Exact input token prefix, source/consumer boundary, physical TP rank and layer; saved-byte identity inherited from archived checksum audit.'}
result = {'summary': summary, 'violations': violations, 'records': rows}
(ROOT / 'prefix-identity-audit.json').write_text(json.dumps(result, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
print(json.dumps(summary, indent=2))
assert not violations

"""Compare corresponding prefix and suffix activations before generation."""
import json
import sys
from pathlib import Path
import torch

root = Path(__file__).resolve().parent / sys.argv[1]
rows = []
for rank in (0, 1):
    folder = root / f'rank{rank}'
    dirs = {p: next(folder.glob(f'*split4k-{p}-*')) for p in ('cold1', 'cold2', 'producer', 'reuse')}
    for path in sorted(dirs['cold1'].glob('01-*.pt')):
        if not any(path.name.endswith(s) for s in ('-inputs.pt', '-fulloutput.pt', '-module.pt')):
            continue
        cold = torch.load(path, weights_only=True)
        repeated = torch.load(dirs['cold2'] / path.name, weights_only=True)
        for phase in ('producer', 'reuse'):
            other = torch.load(dirs[phase] / path.name, weights_only=True)
            for key, value in cold.items():
                if path.name.endswith('-inputs.pt') and key not in ('qkv', 'a', 'b'):
                    continue
                if value.shape[0] != other[key].shape[0] * 2:
                    continue
                split = other[key].shape[0]
                a = value[:split] if phase == 'producer' else value[split:]
                b = other[key]
                d = a.float() - b.float()
                changed = (a != b).reshape(split, -1).any(dim=1)
                index = changed.nonzero().flatten()
                row = {'rank': rank, 'snapshot': path.name, 'phase': phase, 'key': key,
                       'shape': list(a.shape), 'equal': torch.equal(a, b),
                       'cold_repeat_equal': torch.equal(value, repeated[key]),
                       'first_changed_row': index[0].item() if index.numel() else None,
                       'changed_rows': index.numel(), 'max_abs': d.abs().max().item(),
                       'rms': d.square().mean().sqrt().item()}
                rows.append(row)
                print(json.dumps(row), flush=True)
(root / 'activation-comparison.json').write_text(json.dumps(rows, indent=2))

"""Isolate the first output projection from captured inputs and model weights."""
import json
import sys
from pathlib import Path
import torch
import torch_npu
from safetensors import safe_open

torch.npu.set_device(0)
torch.npu.config.allow_internal_format = True
torch.npu.matmul.allow_hf32 = False
root = Path(__file__).resolve().parent / sys.argv[1]
model = Path('/data/shared_upload/models/vspec/Qwen3.5-35B-A3B')
key = 'model.language_model.layers.0.linear_attn.out_proj.weight'
index = json.loads((model / 'model.safetensors.index.json').read_text())
with safe_open(model / index['weight_map'][key], framework='pt', device='cpu') as reader:
    weight = reader.get_tensor(key)
result = []
outputs = {}


def compare(name, left, right):
    a, b = left.cpu(), right.cpu()
    d = a.float() - b.float()
    row = {'name': name, 'equal': torch.equal(a, b), 'max_abs': d.abs().max().item(),
           'rms': d.square().mean().sqrt().item(), 'different_elements': int((a != b).sum())}
    result.append(row)
    print(json.dumps(row), flush=True)


for rank in (0, 1):
    folder = root / f'rank{rank}'
    cold_dir = next(folder.glob('*split4k-cold1-*'))
    reuse_dir = next(folder.glob('*split4k-reuse-*'))
    path = next(cold_dir.glob('*out_proj-module.pt'))
    cold = torch.load(path, weights_only=True)
    reuse = torch.load(reuse_dir / path.name, weights_only=True)
    x = cold['input_0'].npu()
    w = weight[:, rank * 2048:(rank + 1) * 2048].contiguous().npu()
    for kind in ('nd', 'fp32', 'padded'):
        wk = torch_npu.npu_format_cast(w, 29) if kind == 'nz' else w
        xk = x
        if kind == 'fp32':
            xk, wk = x.float(), w.float()
        full = torch.nn.functional.linear(xk, wk).to(torch.bfloat16)
        if kind == 'padded':
            prefix = torch.nn.functional.linear(torch.nn.functional.pad(xk[:2048], (0, 0, 0, 2048)), wk)[:2048]
            suffix = torch.nn.functional.linear(torch.nn.functional.pad(xk[2048:], (0, 0, 0, 2048)), wk)[:2048]
        else:
            prefix = torch.nn.functional.linear(xk[:2048], wk).to(torch.bfloat16)
            suffix = torch.nn.functional.linear(xk[2048:], wk).to(torch.bfloat16)
        compare(f'rank{rank}-{kind}-prefix', full[:2048], prefix)
        compare(f'rank{rank}-{kind}-suffix', full[2048:], suffix)
        outputs[rank, kind, 'full'] = full.cpu()
        outputs[rank, kind, 'split'] = torch.cat([prefix, suffix]).cpu()
    compare(f'rank{rank}-same-input', cold['input_0'][2048:], reuse['input_0'])
    if rank == 0:
        captured_full = cold['output_0']
        captured_suffix = reuse['output_0']
for kind in ('nd', 'fp32', 'padded'):
    full = outputs[0, kind, 'full'] + outputs[1, kind, 'full']
    split = outputs[0, kind, 'split'] + outputs[1, kind, 'split']
    compare(f'{kind}-sum-vs-captured-full', captured_full, full)
    compare(f'{kind}-sum-vs-captured-suffix', captured_suffix, split[2048:])
    compare(f'{kind}-sum-full-vs-split', full, split)
(root / 'projection-replay.json').write_text(json.dumps(result, indent=2))

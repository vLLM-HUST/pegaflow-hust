"""Compare cold prefill with true native APC reuse on fixed input tokens."""
import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / sys.argv[1]
BASE = 'http://127.0.0.1:28380'
CASES = {row['id']: row for row in json.loads((ROOT/'cases.json').read_text())}


def call(path, body=None, timeout=180):
    data = None if body is None else json.dumps(body).encode()
    request = urllib.request.Request(BASE+path, data=data, method='GET' if data is None else 'POST',
                                     headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        text=response.read().decode()
        return json.loads(text) if text else None


def reset():
    request=urllib.request.Request(BASE+'/reset_prefix_cache',data=b'',method='POST')
    with urllib.request.urlopen(request,timeout=30) as response:
        return {'status':response.status,'body':response.read().decode()}


def metrics():
    with urllib.request.urlopen(BASE+'/metrics',timeout=15) as response:
        return '\n'.join(line for line in response.read().decode().splitlines()
                         if not line.startswith('#') and any(key in line for key in
                         ('prefix_cache','prompt_tokens','generation_tokens','num_requests_running')))


def generate(tag, phase, case_id, salt, clear=False):
    if clear:
        reset()
    before=metrics()
    response=call('/v1/completions',{'model':'hybrid-qwen35','prompt':CASES[case_id]['prompt_token_ids'],
        'max_tokens':32,'temperature':0,'top_p':1,'seed':17,'ignore_eos':True,
        'return_token_ids':True,'cache_salt':salt,'logprobs':5,
        'request_id':f'native-{tag}-{phase}-{case_id}'})
    row={'tag':tag,'phase':phase,'case_id':case_id,'cache_salt':salt,'clear_apc':clear,
         'response':response,'metrics_before':before,'metrics_after':metrics()}
    with (OUT/'results.jsonl').open('a') as stream:
        stream.write(json.dumps(row)+'\n')
    ids=response['choices'][0]['token_ids']
    assert len(ids)==32
    print(tag,phase,case_id,ids[:5],response['usage'],flush=True)
    return row


for attempt in range(240):
    try:
        call('/health',timeout=3)
        break
    except Exception:
        if attempt%15==0:
            print('waiting for model',attempt,flush=True)
        time.sleep(2)
else:
    raise RuntimeError('Model startup timed out')
if (OUT/'results.jsonl').exists():
    raise RuntimeError('Preserve prior results; choose a new output directory')
summaries=[]
for tag,producer,consumer in [('split4k','boundary-2048','boundary-4096'),
    ('decode2k','boundary-2047','boundary-2049'),('prefill2k','boundary-2048','boundary-2049'),
    ('coherent4k','boundary-4096','boundary-4097')]:
    if len(sys.argv) > 2 and tag != sys.argv[2]:
        continue
    salt='pure-native-20261013-'+OUT.name+'-'+tag
    cold=generate(tag,'cold1',consumer,salt,clear=True)
    repeated=generate(tag,'cold2',consumer,salt,clear=True)
    generate(tag,'producer',producer,salt,clear=True)
    reuse=generate(tag,'reuse',consumer,salt)
    expected=cold['response']['choices'][0]['token_ids']
    actual=reuse['response']['choices'][0]['token_ids']
    first=next((i+1 for i,(a,b) in enumerate(zip(expected,actual)) if a!=b),None)
    summary={'tag':tag,'baseline_stable':expected==repeated['response']['choices'][0]['token_ids'],
             'reuse_equals_baseline':actual==expected,'first_difference_1based':first,
             'reuse_usage':reuse['response']['usage']}
    summaries.append(summary)
    (OUT/'summary.json').write_text(json.dumps(summaries,indent=2))
    print('RESULT',json.dumps(summary),flush=True)

"""Compare prefill- and decode-produced boundary states on captured layer-zero inputs."""
import json
import torch
from vllm.model_executor.layers.fla.ops.l2norm import l2norm_fwd
import replay_core as r


def decode(position, conv_state, ssm_state):
    x = r.data['qkv'][position:position + 1].contiguous()
    conv_state = conv_state.unsqueeze(0).clone().npu()
    output = torch.empty_like(x)
    torch.ops._C_ascend.npu_causal_conv1d_custom(output, x,
        r.data['conv_weight'].view(4096, 4).transpose(0, 1), conv_state=conv_state,
        bias_opt=None, query_start_loc_opt=torch.tensor([0, 1], dtype=torch.int32, device=x.device),
        cache_indices_opt=torch.tensor([0], dtype=torch.int32, device=x.device),
        initial_state_mode_opt=None, num_accepted_tokens_opt=None,
        activation_mode=1, pad_slot_id=-1, run_mode=1)
    query, key, value = [part.reshape(1, 1, -1, 128).contiguous()
                         for part in output.split([1024, 1024, 2048], dim=-1)]
    query, key = l2norm_fwd(query), l2norm_fwd(key)
    g, beta = r.DeviceOperator.fused_gdn_gating(r.data['A_log'], r.data['a'][position:position + 1].contiguous(),
        r.data['b'][position:position + 1].contiguous(), r.data['dt_bias'])
    state = ssm_state.unsqueeze(0).clone().npu()
    result = torch.ops._C_ascend.npu_recurrent_gated_delta_rule(
        query=query.squeeze(0), key=key.squeeze(0), value=value.squeeze(0),
        g=g.squeeze(0), beta=beta.squeeze(0), state=state, scale=128 ** -0.5,
        actual_seq_lengths=torch.tensor([0, 1], dtype=torch.int32, device=x.device),
        ssm_state_indices=torch.tensor([0], dtype=torch.int32, device=x.device))
    return output, result, conv_state[0], state[0]


conv_2047, cs_2047 = r.conv(r.data['qkv'][:2047])
out_2047, state_2047 = r.gdn(conv_2047, r.data['a'][:2047], r.data['b'][:2047])
conv_one, out_one, cs_decode, state_decode = decode(2047, cs_2047, state_2047)
r.compare('decode2048-conv-vs-prefill', r.prefix_conv[-1:], conv_one)
r.compare('decode2048-conv-state-vs-prefill', r.prefix_conv_state, cs_decode)
r.compare('decode2048-output-vs-prefill', r.prefix_out[-1:], out_one)
r.compare('decode2048-ssm-state-vs-prefill', r.prefix_state, state_decode)
chunk_one_out, chunk_one_state = r.gdn(conv_one, r.data['a'][2047:2048], r.data['b'][2047:2048], state_2047)
r.compare('chunk2048-output-vs-prefill', r.prefix_out[-1:], chunk_one_out)
r.compare('chunk2048-state-vs-prefill', r.prefix_state, chunk_one_state)
conv_2049, cs_2049 = r.conv(r.data['qkv'][:2049])
out_2049, state_2049 = r.gdn(conv_2049, r.data['a'][:2049], r.data['b'][:2049])
_, next_out_prefill, _, next_state_prefill = decode(2048, r.prefix_conv_state, r.prefix_state)
_, next_out_decode, _, next_state_decode = decode(2048, cs_decode, state_decode)
r.compare('decode2049-from-prefill-output', out_2049[-1:], next_out_prefill)
r.compare('decode2049-from-decode-output', out_2049[-1:], next_out_decode)
r.compare('decode2049-from-prefill-state', state_2049, next_state_prefill)
r.compare('decode2049-from-decode-state', state_2049, next_state_decode)
(r.ROOT / 'decode-replay.json').write_text(json.dumps(r.results, indent=2))

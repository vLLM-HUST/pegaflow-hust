"""Own one native vLLM process for the APC correctness diagnosis."""
import hashlib
import importlib.metadata
import json
import os
import signal
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = '/data/shared_upload/hust-zsx/hybrid-cache-acceptance-20261013/.venv/bin/python'
MODEL = '/data/shared_upload/models/vspec/Qwen3.5-35B-A3B'


def environment():
    env = dict(os.environ)
    env.update(HCCL_IF_IP='192.168.0.2', GLOO_SOCKET_IFNAME='bond1', HF_HUB_OFFLINE='1',
               TOKENIZERS_PARALLELISM='false', PYTHONHASHSEED='17', OMP_NUM_THREADS='4',
               VLLM_SERVER_DEV_MODE='1', PYTHONHOME='/usr/local/python3.12.13')
    env['LD_LIBRARY_PATH'] = '/usr/local/python3.12.13/lib:' + env.get('LD_LIBRARY_PATH', '')
    env['PYTHONPATH'] = str(ROOT) + ':' + env.get('PYTHONPATH', '')
    return env


def start(name):
    root = ROOT / name
    root.mkdir(exist_ok=False)
    argv = [PYTHON, '-m', 'vllm.entrypoints.cli.main', 'serve', MODEL,
            '--host', '127.0.0.1', '--port', '28380', '--served-model-name', 'hybrid-qwen35',
            '--tensor-parallel-size', '2', '--pipeline-parallel-size', '1',
            '--dtype', 'bfloat16', '--max-model-len', '8192', '--max-num-seqs', '4',
            '--max-num-batched-tokens', '4096', '--kv-cache-memory-bytes', '2147483648',
            '--enable-prefix-caching', '--mamba-cache-mode', 'align', '--seed', '17',
            '--no-async-scheduling', '--enforce-eager', '--limit-mm-per-prompt',
            '{"image":0,"video":0}', '--generation-config', 'vllm']
    env = environment()
    if name.startswith('probed'):
        argv += ['--worker-cls', 'native_probe.ProbedNPUWorker']
        env['NATIVE_PROBE_OUTPUT'] = str(root)
    if name.startswith('candidate'):
        argv += ['--worker-cls', 'candidate_worker.CandidateNPUWorker']
    with (root / 'server.log').open('w') as log:
        child = subprocess.Popen(argv, env=env, stdout=log, stderr=subprocess.STDOUT,
                                 stdin=subprocess.DEVNULL, start_new_session=True)
    (root / 'process.json').write_text(json.dumps({'pid': child.pid, 'argv': argv,
        'kv_transfer_config': None, 'pythonpath': environment()['PYTHONPATH']}, indent=2))
    print(json.dumps({'pid': child.pid, 'log': str(root / 'server.log')}))


def stop(name):
    record = json.loads((ROOT / name / 'process.json').read_text())
    pid = record['pid']
    path = Path(f'/proc/{pid}/cmdline')
    if path.exists() and path.read_bytes():
        if path.read_bytes().split(b'\0')[:len(record['argv'])] != [arg.encode() for arg in record['argv']]:
            raise RuntimeError('Process identity changed')
        if os.getpgid(pid) != pid:
            raise RuntimeError('Process group identity changed')
        os.killpg(pid, signal.SIGTERM)
    print('stopped', name, pid)


if __name__ == '__main__':
    if sys.argv[1] == 'start':
        start(sys.argv[2])
    elif sys.argv[1] == 'stop':
        stop(sys.argv[2])
    elif sys.argv[1] == 'identity':
        import vllm
        import vllm_ascend
        import torch
        output = {'vllm': vllm.__file__, 'ascend': vllm_ascend.__file__,
                  'torch': torch.__version__, 'hostname': Path('/etc/hostname').read_text().strip(),
                  'memory_limit': Path('/sys/fs/cgroup/memory.max').read_text().strip(),
                  'sched_policy': os.sched_getscheduler(0), 'nice': os.getpriority(os.PRIO_PROCESS, 0),
                  'packages': {key: importlib.metadata.version(key) for key in ('vllm','vllm-ascend','torch-npu')},
                  'model_config_sha256': hashlib.sha256((Path(MODEL)/'config.json').read_bytes()).hexdigest()}
        (ROOT/'runtime-identity.json').write_text(json.dumps(output,indent=2))
        print(json.dumps(output,indent=2))

"""Replay captured layer-zero tensors independently of the model and cache manager."""
import importlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import torch
import torch_npu  # noqa: F401
from vllm_ascend.utils import enable_custom_op

enable_custom_op()
torch.npu.set_device(0)
from vllm_ascend.ops.triton.triton_utils import init_device_properties_triton
init_device_properties_triton()
chunk = importlib.import_module('vllm_ascend.ops.triton.fla.chunk')
chunk.get_forward_context = lambda: SimpleNamespace(attn_metadata=None)
chunk.get_pcp_group = lambda: SimpleNamespace(world_size=1)
from vllm_ascend.device.device_op import DeviceOperator
from vllm_ascend.ops.gdn_attn_builder import _build_non_spec_chunked_prefill_metadata

ROOT = Path(__file__).resolve().parent / sys.argv[1]
folder = ROOT / 'rank0'
cold_dir = next(folder.glob('*split4k-cold1-*'))
producer_dir = next(folder.glob('*split4k-producer-*'))
reuse_dir = next(folder.glob('*split4k-reuse-*'))
input_path = next(cold_dir.glob('*-inputs.pt'))
data = torch.load(input_path, weights_only=True)
before_name = input_path.name.replace('-inputs.pt', '-before.pt')
after_name = input_path.name.replace('-inputs.pt', '-after.pt')
cold_after = torch.load(cold_dir / after_name, weights_only=True)
producer_after = torch.load(producer_dir / after_name, weights_only=True)
reuse_before = torch.load(reuse_dir / before_name, weights_only=True)
reuse_after = torch.load(reuse_dir / after_name, weights_only=True)
data = {key: value.npu() for key, value in data.items()}
results = {}


def compare(name, a, b):
    a, b = a.detach().cpu(), b.detach().cpu()
    x, y = a.float(), b.float()
    d = x - y
    row = {'exact': torch.equal(a, b), 'max_abs': d.abs().max().item(),
           'rms': d.square().mean().sqrt().item(),
           'relative_rms': (d.square().mean() / x.square().mean().clamp_min(1e-30)).sqrt().item()}
    results[name] = row
    print(name, json.dumps(row), flush=True)


def conv(x, state=None):
    has_initial = state is not None
    state = torch.zeros((1, 3, x.shape[-1]), dtype=x.dtype, device=x.device) if state is None else state.unsqueeze(0).clone().npu()
    output = torch.empty_like(x)
    torch.ops._C_ascend.npu_causal_conv1d_custom(output, x.contiguous(),
        data['conv_weight'].view(x.shape[-1], 4).transpose(0, 1), conv_state=state,
        bias_opt=None, query_start_loc_opt=torch.tensor([0, len(x)], dtype=torch.int32, device=x.device),
        cache_indices_opt=torch.tensor([0], dtype=torch.int32, device=x.device),
        initial_state_mode_opt=torch.tensor([has_initial], dtype=torch.bool, device=x.device),
        num_accepted_tokens_opt=None, activation_mode=1, pad_slot_id=-1, run_mode=0)
    return output, state[0]


def gdn(qkv, a, b, state=None):
    query, key, value = [part.reshape(1, len(qkv), -1, 128).contiguous()
                         for part in qkv.split([1024, 1024, 2048], dim=-1)]
    g, beta = DeviceOperator.fused_gdn_gating(data['A_log'], a.contiguous(), b.contiguous(), data['dt_bias'])
    state = torch.zeros((1, 16, 128, 128), dtype=torch.float32, device=qkv.device) if state is None else state.unsqueeze(0).transpose(-1, -2).contiguous().npu()
    output, last = chunk.chunk_gated_delta_rule(query, key, value, g, beta,
        initial_state=state, output_final_state=True,
        cu_seqlens=torch.tensor([0, len(qkv)], dtype=torch.int32, device=qkv.device),
        prebuilt_meta=_build_non_spec_chunked_prefill_metadata(
            SimpleNamespace(vllm_config=SimpleNamespace(
                model_config=SimpleNamespace(hf_text_config=SimpleNamespace(linear_num_value_heads=32)),
                parallel_config=SimpleNamespace(tensor_parallel_size=2))),
            torch.tensor([0, len(qkv)], dtype=torch.int32), qkv.device),
        use_qk_l2norm_in_kernel=True)
    return output[0], last[0].transpose(-1, -2).contiguous()


full_conv, full_conv_state = conv(data['qkv'])
prefix_conv, prefix_conv_state = conv(data['qkv'][:2048])
suffix_conv, suffix_conv_state = conv(data['qkv'][2048:], prefix_conv_state)
compare('conv_full_vs_split_prefix', full_conv[:2048], prefix_conv)
compare('conv_full_vs_split_suffix', full_conv[2048:], suffix_conv)
compare('conv_state_full_vs_split', full_conv_state, suffix_conv_state)
compare('conv_state_prefix_vs_captured', prefix_conv_state, producer_after['conv'])
full_out, full_state = gdn(full_conv, data['a'], data['b'])
prefix_out, prefix_state = gdn(prefix_conv, data['a'][:2048], data['b'][:2048])
suffix_out, suffix_state = gdn(suffix_conv, data['a'][2048:], data['b'][2048:], prefix_state)
compare('gdn_full_vs_split_prefix', full_out[:2048], prefix_out)
compare('gdn_full_vs_split_suffix', full_out[2048:], suffix_out)
compare('gdn_full_vs_split_tail', full_out[-4:], suffix_out[-4:])
compare('gdn_state_full_vs_split', full_state, suffix_state)
compare('gdn_prefix_state_vs_captured', prefix_state, producer_after['ssm'])
compare('gdn_full_state_vs_captured', full_state, cold_after['ssm'])
compare('gdn_split_state_vs_captured', suffix_state, reuse_after['ssm'])
compare('gdn_full_output_vs_captured', full_out[-4:], cold_after['output_tail'])
compare('gdn_split_output_vs_captured', suffix_out[-4:], reuse_after['output_tail'])
torch.save({'full_conv': full_conv.cpu(), 'prefix_conv': prefix_conv.cpu(), 'suffix_conv': suffix_conv.cpu(),
            'full_out': full_out.cpu(), 'prefix_out': prefix_out.cpu(), 'suffix_out': suffix_out.cpu()}, ROOT / 'core-replay.pt')
(ROOT / 'core-replay.json').write_text(json.dumps(results, indent=2))

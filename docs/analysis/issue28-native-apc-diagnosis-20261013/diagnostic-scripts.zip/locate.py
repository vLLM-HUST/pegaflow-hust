"""Find the first changed GDN result and verify the resumed checkpoint."""
import json
import sys
from pathlib import Path
import torch

ROOT = Path(__file__).resolve().parent / sys.argv[1]


def diff(a, b):
    if a.shape != b.shape:
        return {'shapes': [list(a.shape), list(b.shape)]}
    x, y = a.float(), b.float()
    d = x - y
    return {'equal': torch.equal(a, b), 'max': d.abs().max().item(),
            'rms': d.square().mean().sqrt().item(),
            'relative_rms': (d.square().mean() / x.square().mean().clamp_min(1e-30)).sqrt().item(),
            'shape': list(a.shape), 'dtype': str(a.dtype)}


rows = []
for rank in (0, 1):
    folder = ROOT / f'rank{rank}'
    dirs = {phase: next(folder.glob(f'*split4k-{phase}-*')) for phase in ('cold1', 'cold2', 'producer', 'reuse')}
    files = sorted(dirs['cold1'].glob('01-*-after.pt'), key=lambda p: int(p.name.split('layers.')[1].split('.')[0]))
    for path in files:
        before_name = path.name.replace('-after.pt', '-before.pt')
        cold = torch.load(path, weights_only=True)
        repeated = torch.load(dirs['cold2'] / path.name, weights_only=True)
        reuse = torch.load(dirs['reuse'] / path.name, weights_only=True)
        cold_before = torch.load(dirs['cold1'] / before_name, weights_only=True)
        reuse_before = torch.load(dirs['reuse'] / before_name, weights_only=True)
        producer = torch.load(dirs['producer'] / path.name, weights_only=True)
        row = {'rank': rank, 'layer': path.name,
               'cold_repeat': {key: diff(cold[key], repeated[key]) for key in cold},
               'output_comparison': {key: diff(cold[key], reuse[key]) for key in cold},
               'input_comparison': {key: diff(cold_before[key], reuse_before[key]) for key in ('qkv_tail', 'a_tail', 'b_tail')},
               'checkpoint_copy': {key: diff(producer[key], reuse_before[key + '_before']) for key in ('conv', 'ssm')}}
        rows.append(row)
        print(json.dumps(row), flush=True)
    full_cold = next(dirs['cold1'].glob('*-inputs.pt'))
    cold = torch.load(full_cold, weights_only=True)
    producer = torch.load(dirs['producer'] / full_cold.name, weights_only=True)
    reuse = torch.load(dirs['reuse'] / full_cold.name, weights_only=True)
    for key in ('qkv', 'a', 'b'):
        print('FULL_INPUT', rank, key, 'prefix', diff(cold[key][:2048], producer[key]),
              'suffix', diff(cold[key][2048:], reuse[key]), flush=True)
(ROOT / 'layer-comparison.json').write_text(json.dumps(rows, indent=2))

"""Select and record the running diagnostic worker's projection mode."""
import json
import sys
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parent
mode, output = sys.argv[1:3]
(root / output).mkdir(exist_ok=True)
method = 'diagnostic_status' if mode == 'status' else 'diagnostic_mode'
payload = {'method': method, 'args': [] if mode == 'status' else [mode], 'timeout': 60}
request = urllib.request.Request('http://127.0.0.1:28380/collective_rpc',
    data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
with urllib.request.urlopen(request, timeout=65) as response:
    result = response.read().decode()
(root / output / f'{method}.json').write_text(result)
print(result)

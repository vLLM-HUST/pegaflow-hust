"""Diagnostic counterfactual: keep dense projection batch shapes constant."""
import torch
from vllm_ascend.worker.worker import NPUWorker


class CandidateNPUWorker(NPUWorker):
    def load_model(self):
        super().load_model()
        from vllm_ascend.ops.linear import AscendUnquantizedLinearMethod
        self.diagnostic_padding = 'gdn_projection'
        self.diagnostic_counts = {}
        original = AscendUnquantizedLinearMethod.apply

        def apply(method, layer, x, bias=None):
            selected = self.diagnostic_padding == 'all_dense' or (
                self.diagnostic_padding == 'gdn_projection' and layer.prefix.endswith('linear_attn.out_proj'))
            if selected and x.ndim == 2 and 1 < len(x) < 4096:
                count = len(x)
                self.diagnostic_counts[layer.prefix] = self.diagnostic_counts.get(layer.prefix, 0) + 1
                padded = torch.nn.functional.pad(x, (0, 0, 0, 4096 - count))
                return original(method, layer, padded, bias)[:count]
            return original(method, layer, x, bias)

        AscendUnquantizedLinearMethod.apply = apply

    def diagnostic_mode(self, mode):
        if mode not in ('original', 'gdn_projection', 'all_dense'):
            raise ValueError(mode)
        self.diagnostic_padding = mode
        self.diagnostic_counts = {}
        return {'rank': self.rank, 'mode': mode}

    def diagnostic_status(self):
        return {'rank': self.rank, 'mode': self.diagnostic_padding, 'counts': self.diagnostic_counts}

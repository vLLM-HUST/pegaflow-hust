"""Run a diagnostic script with the recorded Python environment."""
import subprocess
import sys
import manage

raise SystemExit(subprocess.call([manage.PYTHON, str(manage.ROOT / sys.argv[1]), *sys.argv[2:]], env=manage.environment()))

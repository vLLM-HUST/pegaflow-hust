"""Read-only state/logit snapshots for native APC; loaded as a diagnostic worker."""
import json
import os
from pathlib import Path

import torch
from vllm.forward_context import get_forward_context
from vllm_ascend.worker.worker import NPUWorker


class ProbedNPUWorker(NPUWorker):
    def load_model(self):
        super().load_model()
        from vllm.v1.worker import mamba_utils
        from vllm_ascend.patch.worker.patch_qwen3_5 import _GDN_PATCH_TARGET

        root = Path(os.environ['NATIVE_PROBE_OUTPUT']) / f'rank{self.rank}'
        root.mkdir(parents=True, exist_ok=True)
        context = {'request': None, 'step': 0}
        steps = {}

        def emit(value):
            with (root / 'trace.jsonl').open('a') as stream:
                stream.write(json.dumps(value) + '\n')

        def save(name, values):
            request = context['request']
            if request is None or context['step'] > 2:
                return
            path = root / request
            path.mkdir(exist_ok=True)
            cpu = {key: value.detach().cpu().clone() if isinstance(value, torch.Tensor) else value
                   for key, value in values.items()}
            torch.save(cpu, path / f'{context["step"]:02d}-{name}.pt')

        original_preprocess = mamba_utils.preprocess_mamba

        def preprocess(*args, **kwargs):
            schedule, config, cache_config, indices, batch, requests, contexts, funcs, buffers = args
            if len(batch.req_ids) == 1 and 'native-' in batch.req_ids[0]:
                req_id = batch.req_ids[0]
                steps[req_id] = steps.get(req_id, 0) + 1
                context.update(request=req_id, step=steps[req_id])
                req = requests[req_id]
                emit({'event': 'prepare', **context, 'computed': req.num_computed_tokens,
                      'scheduled': schedule.num_scheduled_tokens[req_id], 'blocks': req.block_ids,
                      'previous_state_index': indices.get(req_id)})
            else:
                context.update(request=None, step=0)
            return original_preprocess(*args, **kwargs)

        mamba_utils.preprocess_mamba = preprocess
        original_core = _GDN_PATCH_TARGET._forward_core

        def core(layer, mixed_qkv, b, a, core_attn_out):
            output = core_attn_out
            metadata = get_forward_context().attn_metadata
            if context['request'] is None or context['step'] > 2 or not isinstance(metadata, dict):
                return original_core(layer, mixed_qkv, b, a, output)
            meta = metadata[layer.prefix]
            slots = meta.non_spec_state_indices_tensor
            if meta.num_prefills:
                slots = meta.prefill_state_indices
            slots_cpu = slots.detach().cpu().tolist()
            assert len(slots_cpu) == 1, slots_cpu
            slot = slots_cpu[0]
            count = meta.num_actual_tokens
            before = {'qkv_tail': mixed_qkv[:count][-4:], 'a_tail': a[:count][-4:], 'b_tail': b[:count][-4:],
                      'conv_before': layer.kv_cache[0][slot], 'ssm_before': layer.kv_cache[1][slot],
                      'slot': slot, 'prefills': meta.num_prefills, 'decodes': meta.num_decodes,
                      'has_initial_state': str(getattr(meta, 'prefill_has_initial_state', None))}
            save(layer.prefix + '-before', before)
            if any(f'.layers.{i}.' in layer.prefix for i in (0, 1)) and context['step'] == 1:
                save(layer.prefix + '-inputs', {'qkv': mixed_qkv[:count], 'a': a[:count], 'b': b[:count],
                     'conv_weight': layer.conv1d.weight, 'A_log': layer.A_log, 'dt_bias': layer.dt_bias})
            result = original_core(layer, mixed_qkv, b, a, output)
            if any(f'.layers.{i}.' in layer.prefix for i in (0, 1)) and context['step'] == 1:
                save(layer.prefix + '-fulloutput', {'output': output[:count]})
            save(layer.prefix + '-after', {'output_tail': output[:count][-4:],
                 'conv': layer.kv_cache[0][slot], 'ssm': layer.kv_cache[1][slot]})
            return result

        _GDN_PATCH_TARGET._forward_core = core
        original_logits = self.model_runner.model.compute_logits

        def compute_logits(*args, **kwargs):
            result = original_logits(*args, **kwargs)
            if result is not None:
                save('logits', {'logits': result})
            return result

        self.model_runner.model.compute_logits = compute_logits
        def module_hook(name):
            def hook(module, args, kwargs, result):
                if context['request'] is None or context['step'] != 1:
                    return
                values = {}
                for key, value in list(enumerate(args)) + list(kwargs.items()):
                    if isinstance(value, torch.Tensor):
                        values[f'input_{key}'] = value
                outputs = result if isinstance(result, (tuple, list)) else (result,)
                for i, value in enumerate(outputs):
                    if isinstance(value, torch.Tensor):
                        values[f'output_{i}'] = value
                save(name + '-module', values)
            return hook
        for name, module in self.model_runner.model.named_modules():
            if any(name.endswith(suffix) for suffix in (
                'layers.0.linear_attn.norm', 'layers.0.linear_attn.out_proj',
                'layers.0.mlp', 'layers.0.post_attention_layernorm',
            )):
                module.register_forward_hook(module_hook(name), with_kwargs=True)
        emit({'event': 'installed', 'rank': self.rank,
              'kv_transfer_config': str(self.vllm_config.kv_transfer_config)})
